﻿using System;
using System.IO;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using static mapdemo2.GameObject;
using static mapdemo2.MainWindow;
using System.Collections;

namespace mapdemo2
{
    class GameMethod
    {

        // (stop =false + pushable = true) can move the block
        //  stop = false is mean accessible= true
        public static IList<GameObject> GameObjectList = new List<GameObject>
        {
            new GameObject(){id =0,stop = false,pushable= false, num  = 0,ispass= false,isdie =false,issink=false, slip_direction = 0,isslip = false},  //  0 : empty_obj
            new GameObject(){id =1,stop = false,pushable= true, num = 1,ispass= false,isdie =false, issink=false, slip_direction = 0, isslip = false},     //  1 :baba    
            new GameObject(){id =2,stop = false,pushable= true, num = 2,ispass= false,isdie =false, issink=false, slip_direction = 0, isslip = false},     //  2 : is      
            new GameObject(){id =3,stop = false,pushable= true, num = 3,ispass= false,isdie =false, issink=false, slip_direction = 0, isslip = false},     //  3 : you     
            new GameObject(){id =4,stop = false,pushable= false, num = 0,ispass= false,isdie =false, issink=false, slip_direction = 0, isslip = false},    //  4 : player  
            new GameObject(){id =5,stop = false,pushable= false, num = 0,ispass= false,isdie =false, issink=false, slip_direction = 0, isslip = false},    //  5 : wall_middle_obj   
            

            new GameObject(){id =6,stop = false,pushable= false, num = 0,ispass= false,isdie =false, issink=false, slip_direction = 0, isslip = false},    //  6 :wall_left_down obj
            new GameObject(){id =7,stop = false,pushable= false, num = 0 ,ispass= false,isdie =false, issink=false, slip_direction = 0, isslip = false},   //  7 :wall_left_top  obj
            new GameObject(){id =8,stop = false,pushable= false, num = 0 ,ispass= false,isdie =false, issink=false, slip_direction = 0, isslip = false},   //  8 :wall_right_down  obj
            new GameObject(){id =9,stop = false,pushable= false, num = 0 ,ispass= false,isdie =false, issink=false, slip_direction = 0, isslip = false},   //  9 :wall_right_top  obj
            new GameObject(){id =10,stop = false,pushable= true, num = 1 ,ispass= false,isdie =false, issink=false, slip_direction = 0, isslip = false},  //  10:empty
            new GameObject(){id =11,stop = false,pushable= true, num = 3 ,ispass= false,isdie =false, issink=false, slip_direction = 0, isslip = false},  //  11:defeat
            new GameObject(){id =12,stop = false,pushable= false, num = 0 ,ispass= false,isdie =false, issink=false, slip_direction = 0, isslip = false},  //  12:baba_in_ice
            new GameObject(){id =13,stop = false,pushable= true, num = 1 ,ispass= false,isdie =false, issink=false, slip_direction = 0, isslip = false},  //  13:flag.      Flag is win 13,2,35
            new GameObject(){id =14,stop = false,pushable= false, num = 0 ,ispass= false,isdie =false, issink=false, slip_direction = 0, isslip = false},  //  14:flag_obj   
            new GameObject(){id =15,stop = true,pushable= false, num = 0,ispass= false,isdie =false , issink=false, slip_direction = 0, isslip = false},  //  15:grass_obj
            new GameObject(){id =16,stop = false,pushable= true, num = 3 ,ispass= false,isdie =false, issink=false, slip_direction = 0, isslip = false},  //  16:hot
            new GameObject(){id =17,stop = false,pushable= true, num = 1 ,ispass= false,isdie =false, issink=false, slip_direction = 0, isslip = false},  //  17:ice
            new GameObject(){id =18,stop = false,pushable= false, num = 0 ,ispass= false,isdie =false, issink=false, slip_direction = 0, isslip = false},  //  18:ice_obj

            new GameObject(){id =19,stop = false,pushable= true, num = 1 ,ispass= false,isdie =false, issink=false, slip_direction = 0, isslip = false},  //  19:keke  keke is move 19,2,25
            new GameObject(){id =20,stop = false,pushable= true, num = 3,ispass= false,isdie =false , issink=false, slip_direction = 0, isslip = false},  //  20:kill
            new GameObject(){id =21,stop = false,pushable= true, num = 1 ,ispass= false,isdie =false, issink=false, slip_direction = 0, isslip = false},  //  21:lava   lava is kill 21 2 20
            new GameObject(){id =22,stop = false,pushable= false, num = 0,ispass= false,isdie =false , issink=false, slip_direction = 0, isslip = false, keke_direction = 1, keke_ismove = true},  //  22:keke_obj
            new GameObject(){id =23,stop = false,pushable= false, num = 0 ,ispass= false,isdie =false, issink=false, slip_direction = 0, isslip = false},  //  23:love_obj
            new GameObject(){id =24,stop = false,pushable= true, num = 3 ,ispass= false,isdie =false, issink=false, slip_direction = 0, isslip = false},  //  24:melt
            new GameObject(){id =25,stop = false,pushable= true, num = 3 ,ispass= false,isdie =false, issink=false, slip_direction = 0, isslip = false},  //  25:move
            new GameObject(){id =26,stop = false,pushable= false, num = 0,ispass= false,isdie =false , issink=false, slip_direction = 0, isslip = false},  //  26:player_in_wall
            new GameObject(){id =27,stop = false,pushable= true, num = 3 ,ispass= false,isdie =false, issink=false, slip_direction = 0, isslip = false},  //  27:push
            new GameObject(){id =28,stop = false,pushable= true, num = 1,ispass= false,isdie =false, issink=false, slip_direction = 0, isslip = false},  //  28:rock.     Rock is push 28,2,27
            new GameObject(){id =29,stop = false,pushable= false, num = 0,ispass= false,isdie =false , issink=false, slip_direction = 0, isslip = false},  //  29:rock_obj
            //rock_obj pushable = true is for testing

            new GameObject(){id =30,stop = false,pushable= true, num = 1 ,ispass= false,isdie =false, issink=false, slip_direction = 0, isslip = false},  //  30:Skull
            new GameObject(){id =31,stop = false,pushable= true, num = 3,ispass= false,isdie =false , issink=false, slip_direction = 0, isslip = false},  //  31:slip
            new GameObject(){id =32,stop = false,pushable= true, num = 3 ,ispass= false,isdie =false, issink=false, slip_direction = 0, isslip = false},  //  32:stop
            new GameObject(){id =33,stop = false,pushable= true, num = 1 ,ispass= false,isdie =false, issink=false, slip_direction = 0, isslip = false},  //  33:wall		Wall is stop. 33,2,32
            new GameObject(){id =34,stop = false,pushable= false, num = 0 ,ispass= false,isdie =false, issink=false, slip_direction = 0, isslip = false},  //  34:water_obj
            new GameObject(){id =35,stop = false,pushable= true, num = 3 ,ispass= false,isdie =false, issink=false, slip_direction = 0, isslip = false},  //  35:win
            new GameObject(){id =36,stop = false,pushable= false, num = 0,ispass= false,isdie =false , issink=false, slip_direction = 0, isslip = false},  //  36:lava_obj
            new GameObject(){id =37,stop = true,pushable= false, num = 0 ,ispass= false,isdie =false, issink=false, slip_direction = 0, isslip = false},  //  37:wall_vertical
            new GameObject(){id =38,stop = false,pushable= true, num = 1 ,ispass= false,isdie =false, issink=false, slip_direction = 0, isslip = false},  //  38:grass
            new GameObject(){id =39,stop = false,pushable= true, num = 1,ispass= false,isdie =false , issink=false, slip_direction = 0, isslip = false},  //  39:love 
            new GameObject(){id =40,stop = false,pushable= true, num = 1 ,ispass= false,isdie =false, issink=false, slip_direction = 0, isslip = false},  //  40:goop
            new GameObject(){id =41,stop = false,pushable= true, num = 3 ,ispass= false,isdie =false, issink=false, slip_direction = 0, isslip = false},  //  41:sink
            new GameObject(){id =42,stop = true,pushable= false, num = 0 ,ispass= false,isdie =false, issink=false, slip_direction = 0, isslip = false},  //  42:skull_obj
            new GameObject(){id =43,stop = false,pushable= true, num = 1 ,ispass= false,isdie =false, issink=false, slip_direction = 0, isslip = false},  //   43:water

        };

        public static List<int> SaveLogic = new List<int>();    //savelogic store current Logic connection in the map


        //All pattern in game(jam version): Id_connection(ignore "is" id:2)  May not cover all statement right now
        //May not cover all statement right now,just make jam version of statement if it need
        //Logic_ID
        //Baba  Is You   1,3      Type: 123         1
        //Baba  Is Win   1,35     Type: 123         2
        //Baba  Is Wall  1,33     Type: 121         3
        //Baba  Is Rock  1,28     Type: 121         4

        //Rock  Is Push 28,27     Type: 123         5       
        //Rock  Is Stop 28,32     Type: 123         6
        //Rock  Is Wall 28,33     Type: 121         7   
        //Rock  Is Flag 28,13     Type: 121         8
        //Rock  Is Baba 28,1      Type: 121         9

        //Wall  Is Win  33,35     Type: 123         10
        //Wall  Is Stop 33,32     Type: 123         11
        //Wall  Is Push 33,27     Type: 123         12
        //Wall  IS Flag 33,13     Type: 121         13

        //Flag  Is Win  13,35     Type: 123         14
        //Flag  Is Stop 13,32     Type: 123         15
        //Flag  Is Rock 13,28     Type: 121         16
        //Flag  Is Wall 13,33     Type: 121         17  

        //Empty Is Flag 10,13     Type: 121         18
        //Empty Is Baba 10,1      Type: 121         19
        //Water Is Sink 43,41     Type: 123        20
        //Lava  Is Kill 21,20     Type: 123         21
        //Skull Is Kill 30,20     Type: 123        22
        //Grass Is Stop 38,32     Type: 123        23
        //Keke  Is Move 19,25     Type: 123        24

        //Flag is Push  13,27     Type: 123        25
        //Lava is Push  21,27     Type:123         26

        //Rock is Win   28,35       Type:123        27
        //Skull is Win  30,35       Type:123        28
        //Lava is Win   21,35       Type:123        29
        //Skull Is Stop 30,32       Type:123        30
        //Flag Is Kill  13,20       Type:123        31
        //Rock Is Kill  28,20       Type:123        32
        //Wall Is Kill  33,20       Type:123        33
        //Ice  Is Slip  17,31       Type:123        34
        //Empty Is Win   10,35       Type:123        35

        //Empty Is Kill   10,20     Type:123        36
        //Empty Is Rock   10,28     Type:121        37
        //Empty Is Wall   10,33     Type:121        38
        //Empty Is Skull  10,30     Type:121        39

        //Empty Is ICE   10,17        Logic ID:       40
        //Empty Is Keke  10,19        Logic ID:       41
        //Empty Is Lava  10,21        Logic ID:       42
        //Empty Is Grass 10,38        Logic ID:       43
        //Empty Is Love  10,39        Logic ID:       44
        //Empty Is Goop  10,40        Logic ID:       45

        //Baba Is Empty 1,10        Logic ID:        46
        //Baba Is Flag  1,13        Logic ID:        47
        //Baba Is Ice   1,17       Logic ID:         48
        //Baba Is Keke  1,19        Logic ID:        49
        //Baba Is Lava  1,21        Logic ID:        50       
        //Baba Is Skull 1,30        Logic ID:        51
        //Baba Is Wall  1,33        Logic ID:        52     Already exist, not Logic Id =52 now
        //Baba Is Grass 1,38        Logic ID:        53
        //Baba Is Love  1,39        Logic ID:        54
        //Baba Is Goop  1,40        Logic ID:        55

        //Flag Is Baba  13, 1       Logic ID:        56
        //Flag Is Empty 13,10      Logic ID:         57
        //Flag Is Ice   13,17        Logic ID:       58
        //Flag Is Keke  13,19        Logic ID:       59
        //Flag Is Lava  13,21        Logic ID:       60
        //Flag Is Skull 13,30        Logic ID:       61
        //Flag Is Grass 13,38        Logic ID:       62
        //Flag Is Love  13,39        Logic ID:       63
        //Flag Is Goop  13,40        Logic ID:       64

        //Ice Is Flag   17,13        Logic ID:       65
        //Ice Is Baba   17, 1       Logic ID:        66
        //Ice Is Empty  17,10       Logic ID:        67
        //Ice Is Keke   17,19        Logic ID:       68
        //Ice Is Lava   17,21        Logic ID:       69
        //Ice Is Rock   17,28        Logic ID:       70
        //Ice Is Skull  17,30        Logic ID:       71
        //Ice Is Wall   17,33        Logic ID:       72
        //Ice Is Grass  17,38        Logic ID:       73
        //Ice Is Love   17,39        Logic ID:       74
        //Ice Is Goop   17,40        Logic ID:       75

        //Keke Is Ice   19,17        Logic ID:       76
        //Keke Is Flag  19,13        Logic ID:       77
        //Keke Is Baba  19, 1       Logic ID:        78
        //Keke Is Empty 19,10      Logic ID:         79
        //Keke Is Lava  19,21        Logic ID:       80
        //Keke Is Rock  19,28        Logic ID:       81
        //Keke Is Skull 19,30        Logic ID:       82
        //Keke Is Wall  19,33        Logic ID:       83
        //Keke Is Grass 19,38        Logic ID:       84
        //Keke Is Love  19,39        Logic ID:       85
        //Keke Is Goop  19,40        Logic ID:       86

        //Lava Is Keke   21,19        Logic ID:       86
        //Lava Is Ice    21,17        Logic ID:       87
        //Lava Is Flag   21,13        Logic ID:       87        
        //Lava Is Baba   21, 1       Logic ID:       87
        //Lava Is Empty  21,10        Logic ID:       87
        //Lava Is Rock   21,28       Logic ID:       87
        //Lava Is Skull  21,30        Logic ID:       87
        //Lava Is Wall   21,33        Logic ID:       87
        //Lava Is Grass  21,38        Logic ID:       87
        //Lava Is Love   21,39        Logic ID:       87
        //Lava Is Goop   21,40       Logic ID:       87


        //Rock Is Lava   28,21        Logic ID:       88    //first done rock, skull,wall
        //Rock Is Keke   28,19        Logic ID:       89
        //Rock Is Ice    28,17        Logic ID:       90
        //Rock Is Empty  28,10        Logic ID:       91
        //Rock Is Skull  28,30        Logic ID:       92       
        //Rock Is Wall   28,33        Logic ID:       93    // already have !!!
        //Rock Is Grass  28,38        Logic ID:       94
        //Rock Is Love   28,39        Logic ID:       95
        //Rock Is Goop   28,40        Logic ID:       96

        //Skull Is Wall  30,33        Logic ID:       97
        //Skull Is Grass 30,38        Logic ID:       98
        //Skull Is Love  30,39        Logic ID:       99
        //Skull Is Goop  30,40        Logic ID:       100
        //Skull Is Rock  30,28        Logic ID:       101
        //Skull Is Lava  30,21        Logic ID:       102
        //Skull Is Keke  30,19        Logic ID:       103
        //Skull Is Ice   30,17        Logic ID:       104
        //Skull Is Flag  30,13        Logic ID:       105
        //Skull Is Baba  30, 1       Logic ID:       106
        //Skull Is Empty 30,10        Logic ID:       107

        //Wall Is Grass  33,38        Logic ID:       108
        //Wall Is Love   33,39        Logic ID:       109
        //Wall Is Goop   33,40        Logic ID:       110
        //Wall Is Rock   33,28        Logic ID:       111
        //Wall Is Lava   33,21        Logic ID:       112
        //Wall Is Keke   33,19       Logic ID:        113
        //Wall Is Ice    33,17        Logic ID:       114
        //Wall Is Baba   33, 1       Logic ID:        115
        //Wall Is Empty  33,10        Logic ID:       116
        //Wall Is Skull  33,30        Logic ID:       117

        //Lava Is Hot    21,16       Logic ID:       118
        //Baba Is Melt   1,24        Logic ID:       119

        //not add to list right now
        //Goop  Is Hot   40,16        Logic ID:       120
        //Love  Is Hot   39,16        Logic ID:       121
        //Wall  Is Hot   33,16        Logic ID:       122
        //Grass  Is Hot  38,16        Logic ID:       123      
        //Rock  Is Hot   28,16        Logic ID:       124
        //Lava  Is Hot   21,16        Logic ID:       125       //already exist delete 125
        //Keke  Is Hot   19,16        Logic ID:       126
        //Ice  Is Hot    17,16        Logic ID:       127
        //Flag  Is Hot   13,16        Logic ID:       128
        //Baba  Is Hot   1,16         Logic ID:       129
        //Empty  Is Hot  10,16        Logic ID:       130
        //Skull  Is Hot  30,16        Logic ID:       131

        //Goop  Is Melt   40,24        Logic ID:       132
        //Love  Is Melt   39,24        Logic ID:       133
        //Wall  Is Melt   33,24        Logic ID:       134
        //Grass  Is Melt  38,24        Logic ID:       135
        //Rock  Is Melt   28,24        Logic ID:       136
        //Lava  Is Melt   21,24        Logic ID:       137
        //Keke  Is Melt   19,24        Logic ID:       138
        //Ice  Is Melt    17,24        Logic ID:       139
        //Flag  Is Melt   13,24        Logic ID:       140
        //Empty  Is Melt  10,24        Logic ID:       141
        //Skull  Is Melt  30,24        Logic ID:       142

        //Empty Is Slip  10,31        Logic ID:       143
        //Flag Is Slip   13,31        Logic ID:       144
        public static void WinOrLoseOrGoOn(bool win_state, bool lose_state)
        {
            //check SaveLogic if Baba is win or Baba is lose then we change win_state/lose_state  True for connected/False for broken
            if (SaveLogic.Contains(1) == true) // Baba is you connected but nothing happen
            { }
            if (SaveLogic.Contains(1) == false) //Baba Is You find baba is you this logic exist or not
            {
                lose_state = true;
            }

            if (SaveLogic.Contains(2) == true) //Baba Is Win  find baba is win this logic exist or not
            {
                win_state = true;
            }
            if (SaveLogic.Contains(2) == false) //Baba Is Win  is broken but nothing happen
            {

            }

            if (SaveLogic.Contains(3) == true)  // Baba Is Wall     player_obj id = 4, wall obj middle id = 5
            {
                //change baba to wall here!!!!!!!!!!!!!!!!!!!!!
                first_id.Add(4);
                second_id.Add(5);
            }


            if (SaveLogic.Contains(4) == true)  // Baba Is Rock
            {
                first_id.Add(4);
                second_id.Add(29);
            }

            if (SaveLogic.Contains(5) == true)  // Rock is push            
            {
                foreach (var element in GameObjectList)
                {
                    if (element.id == 29)     //if id is rock_obj then change it element.pushable  to true
                    {
                        element.pushable = true;   //need to move testing implementation of wall can push 
                    }
                }
            }
            if (SaveLogic.Contains(5) == false)  // Rock is push broken
            {
                foreach (var element in GameObjectList)
                {
                    if (element.id == 29)     //if id is rock_obj then change it element.pushable  to false
                    {
                        element.pushable = false;   //need to move testing implementation of wall can push 
                    }
                }
            }

            if (SaveLogic.Contains(6) == true)  // Rock is stop  Because rock is stop already so we may not consider this case anymore
            {
                foreach (var element in GameObjectList)
                {
                    if (element.id == 29)     //if id is rock_obj then change it element.stop  to true
                    {
                        element.stop = true;
                    }
                }
            }
            if (SaveLogic.Contains(6) == false)  // Rock is stop  broken
            {
                foreach (var element in GameObjectList)
                {
                    if (element.id == 29)     //if id is rock_obj then change it element.stop  to true
                    {
                        element.stop = false;
                    }
                }
            }

            if (SaveLogic.Contains(7) == true)  // Rock is wall
            {
                first_id.Add(29);
                second_id.Add(5);
            }

            if (SaveLogic.Contains(8) == true)  // Rock is flag
            {
                first_id.Add(29);
                second_id.Add(14);
            }

            if (SaveLogic.Contains(9) == true)  // Rock is baba
            {
                first_id.Add(29);
                second_id.Add(4);
            }

            if (SaveLogic.Contains(10) == true)  // Wall is win
            {
                foreach (var element in GameObjectList)
                {
                    //we need to handle different kind of wall, such as middle ,left top, right down,vertical
                    if (element.id == 5 || element.id == 6 || element.id == 7 || element.id == 8 || element.id == 9 || element.id == 37)
                    {
                        //change their stop properties to true
                        element.stop = true;
                        element.ispass = true;
                    }
                }
            }
            if (SaveLogic.Contains(10) == false)  // Wall is win broken
            {
                foreach (var element in GameObjectList)
                {
                    //we need to handle different kind of wall, such as middle ,left top, right down,vertical
                    if (element.id == 5 || element.id == 6 || element.id == 7 || element.id == 8 || element.id == 9 || element.id == 37)
                    {
                        //change their stop properties to true
                        element.ispass = false;
                    }
                }
            }

            if (SaveLogic.Contains(11) == true)  // Wall is stop
            {
                foreach (var element in GameObjectList)
                {
                    //we need to handle different kind of wall, such as middle ,left top, right down,vertical
                    if (element.id == 5 || element.id == 6 || element.id == 7 || element.id == 8 || element.id == 9 || element.id == 37)
                    {
                        //change their stop properties to true
                        element.stop = true;
                    }
                }
            }
            if (SaveLogic.Contains(11) == false)  // Wall is stop broken or not present
            {
                foreach (var element in GameObjectList)
                {
                    //we need to handle different kind of wall, such as middle ,left top, right down,vertical
                    if (element.id == 5 || element.id == 6 || element.id == 7 || element.id == 8 || element.id == 9 || element.id == 37)
                    {
                        //change their stop properties to true
                        element.stop = false;
                        //MessageBox.Show("Wall is stop broken or not present" + element.stop.ToString());
                    }
                }
            }
            if (SaveLogic.Contains(12) == true)  // Wall is push
            {
                foreach (var element in GameObjectList)
                {
                    //we need to handle different kind of wall, such as middle ,left top, right down,vertical
                    if (element.id == 5 || element.id == 6 || element.id == 7 || element.id == 8 || element.id == 9 || element.id == 37)
                    {
                        //change their stop properties to true
                        element.pushable = true;
                    }
                }
            }
            if (SaveLogic.Contains(12) == false)  // Wall is push broken
            {
                foreach (var element in GameObjectList)
                {
                    //we need to handle different kind of wall, such as middle ,left top, right down,vertical
                    if (element.id == 5 || element.id == 6 || element.id == 7 || element.id == 8 || element.id == 9 || element.id == 37)
                    {
                        //change their stop properties to true
                        element.pushable = false;
                    }
                }
            }
            if (SaveLogic.Contains(13) == true)  // Wall is Flag
            {
                first_id.Add(5);
                first_id.Add(6);
                first_id.Add(7);
                first_id.Add(8);
                first_id.Add(9);
                first_id.Add(37);
                second_id.Add(14);

            }
            if (SaveLogic.Contains(14) == true)  // Flag is win
            {
                foreach (var element in GameObjectList)
                {
                    if (element.id == 14)
                    {
                       // element.stop = true;

                        element.ispass = true;
                    }
                }
            }
            if (SaveLogic.Contains(14) == false)  // Flag is win     consider flag is win broken situation
            {
                foreach (var element in GameObjectList)
                {
                    if (element.id == 14)
                    {

                        element.ispass = false;
                    }
                }
            }
            if (SaveLogic.Contains(15) == true)  // Flag is stop
            {
                //change flag_obj properties ispass to true; flag_obj id is 14
                foreach (var element in GameObjectList)
                {
                    if (element.id == 14)
                        element.stop = true;   // default is false now change to true
                }
            }

            if (SaveLogic.Contains(16) == true)  // Flag is rock
            {
                first_id.Add(14);
                second_id.Add(29);
            }
            if (SaveLogic.Contains(17) == true)  // Flag is wall
            {
                first_id.Add(14);
                second_id.Add(5);
            }
            if (SaveLogic.Contains(18) == true)  // Empty is flag
            {
                first_id.Add(0);
                second_id.Add(14);
            }
            if (SaveLogic.Contains(19) == true)  // Empty is baba
            {
                first_id.Add(0);
                second_id.Add(4);
            }
            if (SaveLogic.Contains(20) == true)  // Water is sink 
            {
                foreach (var element in GameObjectList)
                {
                    if (element.id == 34)         //water_obj id 34
                    {
                        element.issink = true;
                    }
                }
            }
            if (SaveLogic.Contains(20) == false)  // Water is sink not exist
            {
                foreach (var element in GameObjectList)
                {
                    if (element.id == 34)         //water_obj id 34
                    {
                        element.issink = false;
                    }
                }
            }

            if (SaveLogic.Contains(21) == true)  // Lava is kill
            {
                //change lava touch to die  here!!!!!!!!!!!
                foreach (var element in GameObjectList)
                {
                    if (element.id == 36)         //lava_obj id 36
                    {
                        element.stop = true;

                        element.isdie = true;
                    }
                }
            }
            if (SaveLogic.Contains(21) == false)  // Lava is kill
            {
                //change lava touch to die  here!!!!!!!!!!!
                foreach (var element in GameObjectList)
                {
                    if (element.id == 36)         //lava_obj id 36
                    {
                        element.isdie = false;
                    }
                }
            }
            if (SaveLogic.Contains(22) == true)  // skull is kill
            {
                //change skill obj touch to die  here!!!!!!!!!!!
                foreach (var element in GameObjectList)
                {
                    if (element.id == 42)         //42:skull_obj
                    {
                        element.stop = true;

                        element.isdie = true;
                    }
                }
            }
            if (SaveLogic.Contains(22) == false)  // skull is kill
            {
                //change skill obj touch to die  here!!!!!!!!!!!
                foreach (var element in GameObjectList)
                {
                    if (element.id == 42)         //42:skull_obj
                    {
                        element.isdie = false;
                    }
                }
            }
            if (SaveLogic.Contains(23) == true)  // grass is stop
            {
                foreach (var element in GameObjectList)
                {
                    if (element.id == 15)
                        element.stop = true;       //Grass_obj id is15
                }
            }
            if (SaveLogic.Contains(24) == true)  // Keke is move
            {
                //change keke auto moving  here!!!!!!!!!!!
                foreach (var element in GameObjectList)
                {
                    if (element.id == 22)
                        element.keke_ismove = true;       //keke_obj id is 22
                }
            }
            if (SaveLogic.Contains(25) == true)      //Flag is Push
            {
                foreach (var element in GameObjectList)
                {
                    if (element.id == 14)
                        element.pushable = true;       //flag_obj id is 14
                }
            }
            //Lava is Push  21,27      Type:123       26
            if (SaveLogic.Contains(26) == true)      //Flag is Push
            {
                foreach (var element in GameObjectList)
                {
                    if (element.id == 36)
                        element.pushable = true;       //flag_obj id is 14
                }
            }
            if (SaveLogic.Contains(27) == true)  // Rock is win
            {
                //change flag obj touch to win here!!!!!!!!!!!!!
                foreach (var element in GameObjectList)
                {
                    if (element.id == 29)   //rock obj is 28
                    {
                        element.stop = true;

                        element.ispass = true;
                        //MessageBox.Show("Called Rock is win" + " Ispass is " + element.ispass.ToString());
                    }
                }
            }
            if (SaveLogic.Contains(27) == false)  // Rock is win     consider flag is win broken situation
            {
                foreach (var element in GameObjectList)
                {
                    if (element.id == 29)
                    {

                        element.ispass = false;
                        //MessageBox.Show("Broken Flag is win" + "Ispass is" + element.ispass.ToString());
                    }
                }
            }

            if (SaveLogic.Contains(28) == true)            //Skull is Win  30,35       Type:123        28
            {
                foreach (var element in GameObjectList)
                {
                    if (element.id == 42)
                    {
                        element.stop = true;

                        element.ispass = true;
                    }
                }
            }
            if (SaveLogic.Contains(28) == false)            //Skull is Win  broken or not exist
            {
                foreach (var element in GameObjectList)
                {
                    if (element.id == 42)
                    {
                        element.ispass = false;
                    }
                }
            }

            if (SaveLogic.Contains(29) == true)            //Lava is Win   21,35       Type:123        29
            {
                foreach (var element in GameObjectList)
                {
                    if (element.id == 36)
                    {
                        element.stop = true;

                        element.ispass = true;
                    }
                }
            }
            if (SaveLogic.Contains(29) == false)            //Lava is Win   21,35       Type:123        29
            {
                foreach (var element in GameObjectList)
                {
                    if (element.id == 36)
                    {
                        element.ispass = false;
                    }
                }
            }
            if (SaveLogic.Contains(31) == true)                    //Flag Is Kill  13,20       Tyoe:123        31
            {
                foreach (var element in GameObjectList)
                {
                    if (element.id == 14)
                    {
                        element.stop = true;

                        element.isdie = true;
                    }
                }
            }
            if (SaveLogic.Contains(31) == false)                    //Flag Is Kill  13,20       Tyoe:123        31
            {
                foreach (var element in GameObjectList)
                {
                    if (element.id == 14)
                    {
                        element.isdie = false;
                    }
                }
            }
            if (SaveLogic.Contains(32) == true)                    //Rock Is Kill  13,20       Tyoe:123        32
            {
                foreach (var element in GameObjectList)
                {
                    if (element.id == 29)
                    {
                        element.stop = true;

                        element.isdie = true;
                    }
                }
            }
            if (SaveLogic.Contains(32) == false)                    //Rock Is Kill  13,20       Tyoe:123        32
            {
                foreach (var element in GameObjectList)
                {
                    if (element.id == 29)
                    {
                        element.isdie = false;
                    }
                }
            }
            if (SaveLogic.Contains(33) == true)                    //Wall Is Kill  13,20       Tyoe:123        33
            {
                foreach (var element in GameObjectList)
                {
                    if (element.id == 5 || element.id == 6 || element.id == 7 || element.id == 8 || element.id == 9 || element.id == 37)
                    {
                        element.stop = true;

                        element.isdie = true;
                    }
                }
            }
            if (SaveLogic.Contains(33) == false)                    //Wall Is Kill  13,20       Tyoe:123        33
            {
                foreach (var element in GameObjectList)
                {
                    if (element.id == 5 || element.id == 6 || element.id == 7 || element.id == 8 || element.id == 9 || element.id == 37)
                    {
                        element.isdie = false;
                    }
                }
            }

            if (SaveLogic.Contains(34) == true)                    //Wall Is Kill  13,20       Tyoe:123        34
            {
                foreach (var element in GameObjectList)
                {
                    if (element.id == 18)
                    {
                        element.isslip = true;
                    }
                }
            }
            if (SaveLogic.Contains(34) == false)                    //Wall Is Kill  13,20       Tyoe:123        34
            {
                foreach (var element in GameObjectList)
                {
                    if (element.id == 18)
                    {
                        element.isslip = false;
                    }
                }
            }
            if (SaveLogic.Contains(35) == true)                   //Empty Is Win   10,35      Type:123        35
            {
                foreach (var element in GameObjectList)
                {
                    if (element.id == 0)
                    {
                        element.stop = true;

                        element.ispass = true;
                    }
                }
            }
            if (SaveLogic.Contains(35) == false)                   //Empty Is Win   10,35      Type:123        35
            {
                foreach (var element in GameObjectList)
                {
                    if (element.id == 0)
                    {
                        element.ispass = false;
                    }
                }
            }
            if (SaveLogic.Contains(36) == true)                   //Empty Is Kill   10,35      Type:123        36
            {
                foreach (var element in GameObjectList)
                {
                    if (element.id == 0)
                    {
                        element.stop = true;

                        element.isdie = true;
                    }
                }
            }
            if (SaveLogic.Contains(36) == false)                   //Empty Is Kill   10,35      Type:123        36
            {
                foreach (var element in GameObjectList)
                {
                    if (element.id == 0)
                    {
                        element.isdie = false;
                    }
                }
            }
            if(SaveLogic.Contains(37) == true)                          //Empty Is Rock   10,28     Type:121        37
            {
                first_id.Add(0);
                second_id.Add(29);
            }
            if (SaveLogic.Contains(38) == true)                           //Empty Is Wall   10,33     Type:121        38
            {
                first_id.Add(0);
                second_id.Add(5);
            }
            if (SaveLogic.Contains(39) == true)                          //Empty Is Skull  10,30     Type:121        39
            {
                first_id.Add(0);
                second_id.Add(42);
            }
            if (SaveLogic.Contains(40) == true)                          //Empty Is ICE   10,17        Logic ID:       40 
            {
                first_id.Add(0);
                second_id.Add(18);
            }
            if (SaveLogic.Contains(41) == true)                         //Empty Is Keke  10,19        Logic ID:       41
            {
                first_id.Add(0);
                second_id.Add(22);
            }
            if (SaveLogic.Contains(42) == true)                          //Empty Is Lava  10,21        Logic ID:       42
            {
                first_id.Add(0);
                second_id.Add(36);
            }
            if (SaveLogic.Contains(43) == true)                         //Empty Is Grass 10,38        Logic ID:       43
            {
                first_id.Add(0);
                second_id.Add(15);
            }
            if (SaveLogic.Contains(44) == true)                          //Empty Is Love  10,39        Logic ID:       44
            {
                first_id.Add(0);
                second_id.Add(24);
            }
            if (SaveLogic.Contains(45) == true)                          //Empty Is Goop  10,40        Logic ID:       45
            {
                first_id.Add(0);
                second_id.Add(34);
            }
            if (SaveLogic.Contains(46) == true)                          //Baba Is Empty 1,10        Logic ID:        46
            {
                first_id.Add(4);
                second_id.Add(0);
            }
            if (SaveLogic.Contains(47) == true)                          //Baba Is Flag  1,13        Logic ID:        47
            {
                first_id.Add(4);
                second_id.Add(14);
            }
            
            if (SaveLogic.Contains(48) == true)                          //Baba Is Ice   1,17       Logic ID:         48
            {
                first_id.Add(4);
                second_id.Add(18);
            }
            
            if (SaveLogic.Contains(49) == true)                          //Baba Is Keke  1,19        Logic ID:        49
            {
                first_id.Add(4);
                second_id.Add(22);
            }
                
            if (SaveLogic.Contains(50) == true)                         //Baba Is Lava  1,21        Logic ID:        50
            {
                first_id.Add(4);
                second_id.Add(36);
            }
            
            if (SaveLogic.Contains(51) == true)                          //Baba Is Skull 1,30        Logic ID:        51
            {
                first_id.Add(4);
                second_id.Add(42);
            }
            
            if (SaveLogic.Contains(53) == true)                         //Baba Is Grass 1,38        Logic ID:        53
            {
                first_id.Add(4);
                second_id.Add(15);
            }
            
            if (SaveLogic.Contains(54) == true)                          //Baba Is Love  1,39        Logic ID:        54
            {
                first_id.Add(4);
                second_id.Add(24);
            }
           
            if (SaveLogic.Contains(55) == true)                           //Baba Is Goop  1,40        Logic ID:        55
            {
                first_id.Add(4);
                second_id.Add(34);
            }

            if (SaveLogic.Contains(88) == true)                            //Rock Is Lava   28,21        Logic ID:       88
            {
                first_id.Add(29);
                second_id.Add(36);
            }
            if (SaveLogic.Contains(89) == true)                            //Rock Is Keke   28,19        Logic ID:       89
            {
                first_id.Add(29);
                second_id.Add(22);
            }
            if (SaveLogic.Contains(90) == true)                            //Rock Is Ice    28,17        Logic ID:       90
            {
                first_id.Add(29);
                second_id.Add(18);
            }
            if (SaveLogic.Contains(91) == true)                            //Rock Is Empty  28,10        Logic ID:       91
            {
                first_id.Add(29);
                second_id.Add(0);
            }
            if (SaveLogic.Contains(92) == true)                           //Rock Is Skull  28,30        Logic ID:       92  
            {
                first_id.Add(29);
                second_id.Add(42);
            }
            if (SaveLogic.Contains(94) == true)                            //Rock Is Grass  28,38        Logic ID:       94
            {
                first_id.Add(29);
                second_id.Add(15);
            }
            if (SaveLogic.Contains(95) == true)                           //Rock Is Love   28,39        Logic ID:       95
            {
                first_id.Add(29);
                second_id.Add(24);
            }
            if (SaveLogic.Contains(96) == true)                           //Rock Is Goop   28,40        Logic ID:       96  
            {
                first_id.Add(29);
                second_id.Add(34);
            }



            if (SaveLogic.Contains(97) == true)                           //Skull Is Wall  30,33        Logic ID:       97 
            {
                first_id.Add(42);
                second_id.Add(5);
            }
            if (SaveLogic.Contains(98) == true)                           //Skull Is Grass 30,38        Logic ID:       98
            {
                first_id.Add(42);
                second_id.Add(15);
            }
            
            if (SaveLogic.Contains(99) == true)                         //Skull Is Love  30,39        Logic ID:       99
            {          
                first_id.Add(42);
                second_id.Add(24);
            }
            if (SaveLogic.Contains(100) == true)                           //Skull Is Goop  30,40        Logic ID:       100
            {
                first_id.Add(42);
                second_id.Add(34);
            }
            if (SaveLogic.Contains(101) == true)                           //Skull Is Rock  30,28        Logic ID:       101
            {
                first_id.Add(42);
                second_id.Add(29);
            }
            if (SaveLogic.Contains(102) == true)                          //Skull Is Lava  30,21        Logic ID:       102
            {
                first_id.Add(42);
                second_id.Add(36);
            }
            if (SaveLogic.Contains(103) == true)                           ///Skull Is Keke  30,19        Logic ID:       103
            {
                first_id.Add(42);
                second_id.Add(22);
            }
            if (SaveLogic.Contains(104) == true)                           //Skull Is Ice   30,17        Logic ID:       104
            {
                first_id.Add(42);
                second_id.Add(18);
            }
            if (SaveLogic.Contains(105) == true)                           //Skull Is Flag  30,13        Logic ID:       105
            {
                first_id.Add(42);
                second_id.Add(14);
            }
            if (SaveLogic.Contains(106) == true)                           //Skull Is Baba  30, 1       Logic ID:       106
            {
                first_id.Add(42);
                second_id.Add(4);
            }
            if (SaveLogic.Contains(107) == true)                           //Skull Is Empty 30,10        Logic ID:       107
            {
                first_id.Add(42);
                second_id.Add(0);
            }

            if (SaveLogic.Contains(108) == true)                           //Wall Is Grass  33,38        Logic ID:       108
            {
                first_id.Add(5);
                first_id.Add(6);
                first_id.Add(7);
                first_id.Add(8);
                first_id.Add(9);
                first_id.Add(37);
                second_id.Add(15);
            }
            if (SaveLogic.Contains(109) == true)                           //Wall Is Love   33,39        Logic ID:       109
            {
                first_id.Add(5);
                first_id.Add(6);
                first_id.Add(7);
                first_id.Add(8);
                first_id.Add(9);
                first_id.Add(37);
                second_id.Add(24);
            }
            if (SaveLogic.Contains(110) == true)                           //Wall Is Goop   33,40        Logic ID:       110
            {
                first_id.Add(5);
                first_id.Add(6);
                first_id.Add(7);
                first_id.Add(8);
                first_id.Add(9);
                first_id.Add(37);
                second_id.Add(34);
            }
            if (SaveLogic.Contains(111) == true)                           //Wall Is Rock   33,28        Logic ID:       111
            {
                first_id.Add(5);
                first_id.Add(6);
                first_id.Add(7);
                first_id.Add(8);
                first_id.Add(9);
                first_id.Add(37);
                second_id.Add(29);
            }
            if (SaveLogic.Contains(112) == true)                           //Wall Is Lava   33,21        Logic ID:       112
            {
                first_id.Add(5);
                first_id.Add(6);
                first_id.Add(7);
                first_id.Add(8);
                first_id.Add(9);
                first_id.Add(37);
                second_id.Add(36);
            }
            if (SaveLogic.Contains(113) == true)                           //Wall Is Keke   33,19       Logic ID:        113
            {
                first_id.Add(5);
                first_id.Add(6);
                first_id.Add(7);
                first_id.Add(8);
                first_id.Add(9);
                first_id.Add(37);
                second_id.Add(22);
            }
            if (SaveLogic.Contains(114) == true)                           //Wall Is Ice    33,17        Logic ID:       114
            {
                first_id.Add(5);
                first_id.Add(6);
                first_id.Add(7);
                first_id.Add(8);
                first_id.Add(9);
                first_id.Add(37);
                second_id.Add(18);
            }
            if (SaveLogic.Contains(115) == true)                           //Wall Is Baba   33, 1       Logic ID:        115
            {
                first_id.Add(5);
                first_id.Add(6);
                first_id.Add(7);
                first_id.Add(8);
                first_id.Add(9);
                first_id.Add(37);
                second_id.Add(4);
            }
            if (SaveLogic.Contains(116) == true)                           //Wall Is Empty  33,10        Logic ID:       116
            {
                first_id.Add(5);
                first_id.Add(6);
                first_id.Add(7);
                first_id.Add(8);
                first_id.Add(9);
                first_id.Add(37);
                second_id.Add(0);
            }
            if (SaveLogic.Contains(117) == true)                          //Wall Is Skull  33,30        Logic ID:       117
            {
                first_id.Add(5);
                first_id.Add(6);
                first_id.Add(7);
                first_id.Add(8);
                first_id.Add(9);
                first_id.Add(37);
                second_id.Add(42);
            }

            if(SaveLogic.Contains(118) == true)                             //Lava Is Hot    21,16       Logic ID:       118
            {
                foreach (var element in GameObjectList)
                {
                    if (element.id == 36)
                    {
                        element.ishot = true;
                    }
                }
                hot_state.Add(4);
            }
            if (SaveLogic.Contains(118) == false)                             //Lava Is Hot    21,16       Logic ID:       118
            {
                foreach (var element in GameObjectList)
                {
                    if (element.id == 36)
                    {
                        element.ishot = false;
                    }
                }
                hot_state.Remove(4);
            }
            if (SaveLogic.Contains(119) == true)                           //Baba Is Melt   1,24        Logic ID:       119
            {
                foreach (var element in GameObjectList)
                {
                    if (element.id == 4)
                    {
                        element.ismelt = true;
                    }

                }
            }
            if (SaveLogic.Contains(119) == false)                           //Baba Is Melt   1,24        Logic ID:       119
            {
                foreach (var element in GameObjectList)
                {
                    if (element.id == 4)
                    {
                        element.ismelt = false;
                    }
                }
            }
            //Goop  Is Hot   40,16        Logic ID:       120
            if (SaveLogic.Contains(120) == true)                            
            {
                foreach (var element in GameObjectList)
                {
                    if (element.id == 34)
                    {
                        element.ishot = true;
                    }
                }
            }
            if (SaveLogic.Contains(120) == false)                            
            {
                foreach (var element in GameObjectList)
                {
                    if (element.id == 34)
                    {
                        element.ishot = false;
                    }
                }
            }
            //Love  Is Hot   39,16        Logic ID:       121
            if (SaveLogic.Contains(121) == true)                            
            {
                foreach (var element in GameObjectList)
                {
                    if (element.id == 24)
                    {
                        element.ishot = true;
                    }
                }
            }
            if (SaveLogic.Contains(121) == false)                            
            {
                foreach (var element in GameObjectList)
                {
                    if (element.id == 24)
                    {
                        element.ishot = false;
                    }
                }
            }
            //Wall  Is Hot   33,16        Logic ID:       122
            if (SaveLogic.Contains(122) == true)                             
            {
                foreach (var element in GameObjectList)
                {
                    if (element.id == 5 || element.id == 6 || element.id == 7 || element.id == 8 || element.id == 9 || element.id == 37)
                    {
                        element.ishot = true;
                    }
                }
            }
            if (SaveLogic.Contains(122) == false)                             
            {
                foreach (var element in GameObjectList)
                {
                    if (element.id == 5 || element.id == 6 || element.id == 7 || element.id == 8 || element.id == 9 || element.id == 37)
                    {
                        element.ishot = false;
                    }
                }
            }
            //Grass  Is Hot  38,16        Logic ID:       123  
            if (SaveLogic.Contains(123) == true)                             
            {
                foreach (var element in GameObjectList)
                {
                    if (element.id == 15)
                    {
                        element.ishot = true;
                    }
                }
            }
            if (SaveLogic.Contains(123) == false)                            
            {
                foreach (var element in GameObjectList)
                {
                    if (element.id == 15)
                    {
                        element.ishot = false;
                    }
                }
            }
            //Rock  Is Hot   28,16        Logic ID:       124
            if (SaveLogic.Contains(124) == true)                            
            {
                foreach (var element in GameObjectList)
                {
                    if (element.id == 29)
                    {
                        element.ishot = true;
                    }
                }
            }
            if (SaveLogic.Contains(124) == false)                            
            {
                foreach (var element in GameObjectList)
                {
                    if (element.id == 29)
                    {
                        element.ishot = false;
                    }
                }
            }
            //Keke  Is Hot   19,16        Logic ID:       126
            if (SaveLogic.Contains(126) == true)                             
            {
                foreach (var element in GameObjectList)
                {
                    if (element.id == 22)
                    {
                        element.ishot = true;
                    }
                }
            }
            if (SaveLogic.Contains(126) == false)                            
            {
                foreach (var element in GameObjectList)
                {
                    if (element.id == 22)
                    {
                        element.ishot = false;
                    }
                }
            }
            //Ice  Is Hot    17,16        Logic ID:       127
            if (SaveLogic.Contains(127) == true)                            
            {
                foreach (var element in GameObjectList)
                {
                    if (element.id == 18)
                    {
                        element.ishot = true;
                    }
                }
            }
            if (SaveLogic.Contains(127) == false)                             
            {
                foreach (var element in GameObjectList)
                {
                    if (element.id == 18)
                    {
                        element.ishot = false;
                    }
                }
            }
            //Flag  Is Hot   13,16        Logic ID:       128
            if (SaveLogic.Contains(128) == true)
            {
                foreach (var element in GameObjectList)
                {
                    if (element.id == 14)
                    {
                        element.ishot = true;
                    }
                }
            }
            if (SaveLogic.Contains(128) == false)
            {
                foreach (var element in GameObjectList)
                {
                    if (element.id == 14)
                    {
                        element.ishot = false;
                    }
                }
            }
            //Baba  Is Hot   1,16         Logic ID:       129
            if (SaveLogic.Contains(129) == true)
            {
                foreach (var element in GameObjectList)
                {
                    if (element.id == 4)
                    {
                        element.ishot = true;
                    }
                }
            }
            if (SaveLogic.Contains(129) == false)
            {
                foreach (var element in GameObjectList)
                {
                    if (element.id == 4)
                    {
                        element.ishot = false;
                    }
                }
            }
            //Empty  Is Hot  10,16        Logic ID:       130
            if (SaveLogic.Contains(130) == true)
            {
                foreach (var element in GameObjectList)
                {
                    if (element.id == 0)
                    {
                        element.ishot = true;
                    }
                }
            }
            if (SaveLogic.Contains(130) == false)
            {
                foreach (var element in GameObjectList)
                {
                    if (element.id == 0)
                    {
                        element.ishot = false;
                    }
                }
            }
            //Skull  Is Hot  30,16        Logic ID:       131
            if (SaveLogic.Contains(131) == true)
            {
                foreach (var element in GameObjectList)
                {
                    if (element.id == 42)
                    {
                        element.ishot = true;
                    }
                }
            }
            if (SaveLogic.Contains(131) == false)
            {
                foreach (var element in GameObjectList)
                {
                    if (element.id == 42)
                    {
                        element.ishot = false;
                    }
                }
            }

            //Goop  Is Melt   40,24        Logic ID:       132
            if (SaveLogic.Contains(132) == true)                          
            {
                foreach (var element in GameObjectList)
                {
                    if (element.id == 34)
                    {
                        element.ismelt = true;
                    }
                }
            }
            if (SaveLogic.Contains(132) == false)                          
            {
                foreach (var element in GameObjectList)
                {
                    if (element.id == 34)
                    {
                        element.ismelt = false;
                    }
                }
            }
            //Love  Is Melt   39,24        Logic ID:       133
            if (SaveLogic.Contains(133) == true)
            {
                foreach (var element in GameObjectList)
                {
                    if (element.id == 24)
                    {
                        element.ismelt = true;
                    }
                }
            }
            if (SaveLogic.Contains(133) == false)
            {
                foreach (var element in GameObjectList)
                {
                    if (element.id == 24)
                    {
                        element.ismelt = false;
                    }
                }
            }
            //Wall  Is Melt   33,24        Logic ID:       134
            if (SaveLogic.Contains(134) == true)
            {
                foreach (var element in GameObjectList)
                {
                    if (element.id == 5 || element.id == 6 || element.id == 7 || element.id == 8 || element.id == 9 || element.id == 37)
                    {
                        element.ismelt = true;
                    }
                }
            }
            if (SaveLogic.Contains(134) == false)
            {
                foreach (var element in GameObjectList)
                {
                    if (element.id == 5 || element.id == 6 || element.id == 7 || element.id == 8 || element.id == 9 || element.id == 37)
                    {
                        element.ismelt = false;
                    }
                }
            }
            //Grass  Is Melt  38,24        Logic ID:       135
            if (SaveLogic.Contains(135) == true)
            {
                foreach (var element in GameObjectList)
                {
                    if (element.id == 15)
                    {
                        element.ismelt = true;
                    }
                }
            }
            if (SaveLogic.Contains(135) == false)
            {
                foreach (var element in GameObjectList)
                {
                    if (element.id == 15)
                    {
                        element.ismelt = false;
                    }
                }
            }
            //Rock  Is Melt   28,24        Logic ID:       136
            if (SaveLogic.Contains(136) == true)
            {
                foreach (var element in GameObjectList)
                {
                    if (element.id == 29)
                    {
                        element.ismelt = true;
                    }
                }
            }
            if (SaveLogic.Contains(136) == false)
            {
                foreach (var element in GameObjectList)
                {
                    if (element.id == 29)
                    {
                        element.ismelt = false;
                    }
                }
            }
            //Lava  Is Melt   21,24        Logic ID:       137
            if (SaveLogic.Contains(137) == true)
            {
                foreach (var element in GameObjectList)
                {
                    if (element.id == 36)
                    {
                        element.ismelt = true;
                    }
                }
            }
            if (SaveLogic.Contains(137) == false)
            {
                foreach (var element in GameObjectList)
                {
                    if (element.id == 36)
                    {
                        element.ismelt = false;
                    }
                }
            }
            //Keke  Is Melt   19,24        Logic ID:       138
            if (SaveLogic.Contains(138) == true)
            {
                foreach (var element in GameObjectList)
                {
                    if (element.id == 22)
                    {
                        element.ismelt = true;
                    }
                }
            }
            if (SaveLogic.Contains(138) == false)
            {
                foreach (var element in GameObjectList)
                {
                    if (element.id == 22)
                    {
                        element.ismelt = false;
                    }
                }
            }
            //Ice  Is Melt    17,24        Logic ID:       139
            if (SaveLogic.Contains(139) == true)
            {
                foreach (var element in GameObjectList)
                {
                    if (element.id == 18)
                    {
                        element.ismelt = true;
                    }
                }
            }
            if (SaveLogic.Contains(139) == false)
            {
                foreach (var element in GameObjectList)
                {
                    if (element.id == 18)
                    {
                        element.ismelt = false;
                    }
                }
            }
            //Flag  Is Melt   13,24        Logic ID:       140
            if (SaveLogic.Contains(140) == true)
            {
                foreach (var element in GameObjectList)
                {
                    if (element.id == 14)
                    {
                        element.ismelt = true;
                    }
                }
            }
            if (SaveLogic.Contains(140) == false)
            {
                foreach (var element in GameObjectList)
                {
                    if (element.id == 14)
                    {
                        element.ismelt = false;
                    }
                }
            }
            //Empty  Is Melt  10,24        Logic ID:       141
            if (SaveLogic.Contains(141) == true)
            {
                foreach (var element in GameObjectList)
                {
                    if (element.id == 0)
                    {
                        element.ismelt = true;
                    }
                }
            }
            if (SaveLogic.Contains(141) == false)
            {
                foreach (var element in GameObjectList)
                {
                    if (element.id == 0)
                    {
                        element.ismelt = false;
                    }
                }
            }
            //Skull  Is Melt  30,24        Logic ID:       142
            if (SaveLogic.Contains(142) == true)
            {
                foreach (var element in GameObjectList)
                {
                    if (element.id == 42)
                    {
                        element.ismelt = true;
                    }
                }
            }
            if (SaveLogic.Contains(142) == false)
            {
                foreach (var element in GameObjectList)
                {
                    if (element.id == 42)
                    {
                        element.ismelt = false;
                    }
                }
            }
            //Empty Is Slip  10,31        Logic ID:       143
            if (SaveLogic.Contains(143) == true)
            {
                foreach (var element in GameObjectList)
                {
                    if (element.id == 0)
                    {
                        element.isslip = true;
                    }
                }
            }
            if (SaveLogic.Contains(143) == false)
            {
                foreach (var element in GameObjectList)
                {
                    if (element.id == 0)
                    {
                        element.isslip = false;
                    }
                }
            }
            //Flag Is Slip   13,31        Logic ID:       144
            if (SaveLogic.Contains(144) == true)
            {
                foreach (var element in GameObjectList)
                {
                    if (element.id == 14)
                    {
                        element.isslip = true;
                    }
                }
            }
            if (SaveLogic.Contains(144) == false)
            {
                foreach (var element in GameObjectList)
                {
                    if (element.id == 14)
                    {
                        element.isslip = false;
                    }
                }
            }

            ////////////////Game WIN or LOSE//////////////////////////////////
            if (win_state == true)
            {
                MessageBox.Show("You are win! You pass this Game Level!");
                win_state = false;  //Go back to default state
            }
            if (lose_state)
            {
                MessageBox.Show("You are lose! Please click Z button and  try again!");
                lose_state = false; //Go back to default state
            }

            //After using SafeLogic ,we clear all logic data , wait for next move
            SaveLogic.Clear();
        }


        public static void TouchToPassOrDie(gameboard tempboard, int x, int y)
        {
            foreach (var element in GameObjectList)
            {
                if (tempboard.boardpos[x, y].pos.Contains(element.id) && element.ispass == true)
                {
                    MessageBox.Show("You are win! You pass this Game Level!" + tempboard.boardpos[x, y].pos.Last().ToString() + element.ispass.ToString());
                    win_state = true;  //auto go back previous state , not need this
                }
                if (tempboard.boardpos[x, y].pos.Contains(element.id) && element.isdie == true)
                {
                    MessageBox.Show("You are lose! Please click Z button and  try again!  " + element.id.ToString() + element.isdie.ToString());
                    lose_state = true;  //auto go back previous state , not need this

                }
            }
        }


        public static void TestMessage(int Test_ID)
        {
            foreach (var element in GameObjectList)
                if (element.id == Test_ID)
                {
                    MessageBox.Show("Stoppable current state is " + element.stop.ToString() + "\nPushable current state is " + element.pushable.ToString());
                    MessageBox.Show("Ispass current state is " + element.ispass.ToString() + "\nIsDie current state is " + element.isdie.ToString());
                }
        }




        //*************************   Logic Statement Here   **********************
        public static void Call_All_Statement_123(int element_a_id, int element_c_id) //need to check all map statement is connect or not
        {
            Baba_Is_You(element_a_id, element_c_id);        
            Baba_Is_Win(element_a_id, element_c_id);        

            Rock_Is_Push(element_a_id, element_c_id);
            Rock_Is_Stop(element_a_id, element_c_id);
            Wall_Is_Win(element_a_id, element_c_id);
            Wall_Is_Stop(element_a_id, element_c_id);
            Wall_Is_Push(element_a_id, element_c_id);
            Flag_Is_Win(element_a_id, element_c_id);
            Flag_Is_Stop(element_a_id, element_c_id);
            Water_Is_Sink(element_a_id, element_c_id);
            Lava_Is_Kill(element_a_id, element_c_id);
            Skull_Is_Kill(element_a_id, element_c_id);
            Grass_Is_Stop(element_a_id, element_c_id);
            Keke_Is_Move(element_a_id, element_c_id);
            Flag_Is_Push(element_a_id, element_c_id);
            Lava_Is_Push(element_a_id, element_c_id);
            Skull_Is_Win(element_a_id, element_c_id);
            Lava_Is_Win(element_a_id, element_c_id);
            Rock_Is_Win(element_a_id, element_c_id);
            Flag_Is_Kill(element_a_id, element_c_id);
            Rock_Is_Kill(element_a_id, element_c_id);
            Wall_Is_Kill(element_a_id, element_c_id);
            Ice_Is_Slip(element_a_id, element_c_id);
            Empty_Is_Win(element_a_id, element_c_id);
            Empty_Is_Kill(element_a_id, element_c_id);

            Lava_Is_Hot(element_a_id, element_c_id);
            Love_Is_Hot(element_a_id, element_c_id);
            Wall_Is_Hot(element_a_id, element_c_id);
            Grass_Is_Hot(element_a_id, element_c_id);
            Rock_Is_Hot(element_a_id, element_c_id);
            Keke_Is_Hot(element_a_id, element_c_id);
            Ice_Is_Hot(element_a_id, element_c_id);
            Flag_Is_Hot(element_a_id, element_c_id);
            Baba_Is_Hot(element_a_id, element_c_id);
            Empty_Is_Hot(element_a_id, element_c_id);
            Skull_Is_Hot(element_a_id, element_c_id);


            Baba_Is_Melt(element_a_id, element_c_id);
            Goop_Is_Melt(element_a_id, element_c_id);
            Love_Is_Melt(element_a_id, element_c_id);
            Wall_Is_Melt(element_a_id, element_c_id);
            Grass_Is_Melt(element_a_id, element_c_id);
            Rock_Is_Melt(element_a_id, element_c_id);
            Lava_Is_Melt(element_a_id, element_c_id);
            Keke_Is_Melt(element_a_id, element_c_id);
            Ice_Is_Melt(element_a_id, element_c_id);
            Flag_Is_Melt(element_a_id, element_c_id);
            Empty_Is_Melt(element_a_id, element_c_id);
            Skull_Is_Melt(element_a_id, element_c_id);

            Empty_Is_Slip(element_a_id, element_c_id);
            Flag_Is_Slip(element_a_id, element_c_id);
        }

        public static void Call_All_Statement_121(int element_a_id, int element_c_id)
        {
            Baba_Is_Wall(element_a_id, element_c_id);
            Baba_Is_Rock(element_a_id, element_c_id);
            Baba_Is_Empty(element_a_id, element_c_id);
            Baba_Is_Flag(element_a_id, element_c_id);
            Baba_Is_Ice(element_a_id, element_c_id);
            Baba_Is_Keke(element_a_id, element_c_id);
            Baba_Is_Lava(element_a_id, element_c_id);
            Baba_Is_Skull(element_a_id, element_c_id);
            Baba_Is_Grass(element_a_id, element_c_id);
            Baba_Is_Love(element_a_id, element_c_id);
            Baba_Is_Goop(element_a_id, element_c_id);
 
            Rock_Is_Flag(element_a_id, element_c_id);
            Rock_Is_Baba(element_a_id, element_c_id);
            Rock_Is_Wall(element_a_id, element_c_id);
            Rock_Is_Lava(element_a_id, element_c_id);
            Rock_Is_Keke(element_a_id, element_c_id);
            Rock_Is_Ice(element_a_id, element_c_id);
            Rock_Is_Empty(element_a_id, element_c_id);
            Rock_Is_Skull(element_a_id, element_c_id);
            Rock_Is_Grass(element_a_id, element_c_id);
            Rock_Is_Love(element_a_id, element_c_id);
            Rock_Is_Goop(element_a_id, element_c_id);

            Flag_Is_Wall(element_a_id, element_c_id);
            Flag_Is_Rock(element_a_id, element_c_id);

            Empty_Is_Flag(element_a_id, element_c_id);
            Empty_Is_Baba(element_a_id, element_c_id);
            Empty_Is_Rock(element_a_id, element_c_id);
            Empty_Is_Wall(element_a_id, element_c_id);
            Empty_Is_Skull(element_a_id, element_c_id);
            Empty_Is_Ice(element_a_id, element_c_id);
            Empty_Is_Keke(element_a_id, element_c_id);
            Empty_Is_Lava(element_a_id, element_c_id);
            Empty_Is_Grass(element_a_id, element_c_id);
            Empty_Is_Love(element_a_id, element_c_id);
            Empty_Is_Goop(element_a_id, element_c_id);

            Skull_Is_Wall(element_a_id, element_c_id);
            Skull_Is_Grass(element_a_id, element_c_id);
            Skull_Is_Goop(element_a_id, element_c_id);
            Skull_Is_Love(element_a_id, element_c_id);
            Skull_Is_Rock(element_a_id, element_c_id);
            Skull_Is_Lava(element_a_id, element_c_id);
            Skull_Is_Keke(element_a_id, element_c_id);
            Skull_Is_Ice(element_a_id, element_c_id);
            Skull_Is_Flag(element_a_id, element_c_id);
            Skull_Is_Baba(element_a_id, element_c_id);
            Skull_Is_Empty(element_a_id, element_c_id);
            Skull_Is_Goop(element_a_id, element_c_id);

            Wall_Is_Flag(element_a_id, element_c_id);
            Wall_Is_Grass(element_a_id, element_c_id);
            Wall_Is_Love(element_a_id, element_c_id);
            Wall_Is_Goop(element_a_id, element_c_id);
            Wall_Is_Rock(element_a_id, element_c_id);
            Wall_Is_Lava(element_a_id, element_c_id);
            Wall_Is_Keke(element_a_id, element_c_id);
            Wall_Is_Baba(element_a_id, element_c_id);
            Wall_Is_Ice(element_a_id, element_c_id);
            Wall_Is_Empty(element_a_id, element_c_id);
            Wall_Is_Skull(element_a_id, element_c_id);

        }

        public static bool Check_Pushable(int id_number)        //need to change latter
        {
            foreach (var element in GameObjectList)
            {
                if (element.id == id_number && element.pushable == true)
                    return true;
            }
            return false;
        }

        public static void Change_Pushable(int id_number, bool TF_value)   //change true false value of pushable
        {
            foreach (var element in GameObjectList)
            {
                if (element.id == id_number && TF_value == true)
                    element.pushable = true;
                if (element.id == id_number && TF_value == false)
                    element.pushable = false;
            }
        }

        public static bool Check_Stoppable(int id_number)
        {
            foreach (var element in GameObjectList)
            {
                if (element.id == id_number && element.stop == true)
                    return true;
            }
            return false;
        }

        public static void Change_Stoppable(int id_number, bool TF_value)   //change true false value of stop
        {
            foreach (var element in GameObjectList)
            {
                if (element.id == id_number && TF_value == true)
                    element.stop = true;
                if (element.id == id_number && TF_value == false)
                    element.stop = false;
            }
        }


        public static bool Check_IsDie(int id_number)       //穿过是否死亡    default is false!  kill,sink,hot,defeat 都属于kill的情况
        {
            foreach (var element in GameObjectList)
            {
                if (element.id == id_number && element.isdie == true)
                    return true;
            }

            return false;
        }

        public static bool Check_IsPass(int id_number)      //穿过是否过关   default is false!
        {
            foreach (var element in GameObjectList)
            {
                if (element.id == id_number && element.ispass == true)
                    return true;
            }
            return false;
        }

        public static bool Check_IsSlip(int id_number)      //穿过ice是否打滑 只能前进一个方向
        {
            foreach (var element in GameObjectList)
            {
                if (element.id == id_number && element.isslip == true)
                    return true;
            }
            return false;
        }
        public static bool Check_Keke_Is_Move(int id_number)    //true代表keke会自动移动____人物属性(Keke )有一关keke会自动移动 默认tru
        {
            foreach (var element in GameObjectList)
            {
                if (element.id == id_number && element.keke_ismove == true)
                    return true;
            }
            return false;
        }

        public static int Check_Keke_Direction(int id_number)   //1表示上 2表示下 3表示左 4表示右____人物属性（keke）  默认3，向左只有一关
        {
            foreach (var element in GameObjectList)
            {
                if (element.id == id_number && element.keke_ismove == true)
                    return element.keke_direction;
            }
            return 3;   //default left
        }
       






        /// ///////////////////////////////////////////////Logic add to SaveLogic//////////////////////////////////////////////////////////////////
    
        public static void Baba_Is_You(int element_a_id, int element_c_id)      //Logcic ID :1
        {
            if (element_a_id == 1 && element_c_id == 3)
            {
                SaveLogic.Add(1);       //add this logic to savelogic 
            }
        }

        //Type 123
        public static void Baba_Is_Win(int element_a_id, int element_c_id)       //Logic ID ;2
        {
            if (element_a_id == 1 && element_c_id == 35)
            {
                SaveLogic.Add(2);       //add this logic to savelogic 
            }
        }

        //Type 121
        public static void Baba_Is_Wall(int element_a_id, int element_c_id)     //Logic ID  :3
        {
            if (element_a_id == 1 && element_c_id == 33)
            {
                SaveLogic.Add(3);       //add this logic to savelogic 
            }
            return;
        }

        //Type 121
        public static void Baba_Is_Rock(int element_a_id, int element_c_id)     //Logic ID  :4
        {
            if (element_a_id == 1 && element_c_id == 28)
            {
                SaveLogic.Add(4);       //add this logic to savelogic 
            }
            return;
        }

        //Type 123
        public static void Rock_Is_Push(int element_a_id, int element_c_id)     //Logic ID:5
        {
            if (element_a_id == 28 && element_c_id == 27)
            {
                SaveLogic.Add(5);       //add this logic to savelogic 
            }
            return;
        }

        //Type 123
        public static void Rock_Is_Stop(int element_a_id, int element_c_id)     //Logic ID  :6
        {
            if (element_a_id == 28 && element_c_id == 32)
            {
                SaveLogic.Add(6);       //add this logic to savelogic 
            }
            return;
        }

        public static void Rock_Is_Wall(int element_a_id, int element_c_id)     //Logic ID  :7
        {
            if (element_a_id == 28 && element_c_id == 33)
            {
                SaveLogic.Add(7);       //add this logic to savelogic 
            }
            return;
        }
        //Type 121
        public static void Rock_Is_Flag(int element_a_id, int element_c_id)     //Logic ID  :8
        {
            if (element_a_id == 28 && element_c_id == 32)
            {
                SaveLogic.Add(8);       //add this logic to savelogic 
            }
            return;
        }

        //Type 121
        public static void Rock_Is_Baba(int element_a_id, int element_c_id)         //Logic ID  :9
        {
            if (element_a_id == 28 && element_c_id == 1)
            {
                SaveLogic.Add(9);       //add this logic to savelogic 
            }
            return;
        }

        //Wall  Is Win  33,35     Type: 123
        public static void Wall_Is_Win(int element_a_id, int element_c_id)              //Logic ID  : 10
        {
            if (element_a_id == 33 && element_c_id == 35)    //Wall is stop. 33,2,32
            {
                SaveLogic.Add(10);       //add this logic to savelogic 
            }
            return;
        }
        //Type 123
        public static void Wall_Is_Stop(int element_a_id, int element_c_id)             //Logic ID  :11
        {
            if (element_a_id == 33 && element_c_id == 32)    //Wall is stop. 33,2,32
            {
                SaveLogic.Add(11);       //add this logic to savelogic 
            }
            return;

        }

        //Type 123
        public static void Wall_Is_Push(int element_a_id, int element_c_id)         //Logic ID  :12
        {
            if (element_a_id == 33 && element_c_id == 27)            //Wall  Is Push 33,27
            {
                SaveLogic.Add(12);       //add this logic to savelogic 
            }
            return;
        }

        //Wall  IS Flag 33,13     Type: 121
        public static void Wall_Is_Flag(int element_a_id, int element_c_id)         //Logic ID  :13
        {
            if (element_a_id == 33 && element_c_id == 13)
            {
                SaveLogic.Add(13);       //add this logic to savelogic 
            }
        }

        //Type 123
        public static void Flag_Is_Win(int element_a_id, int element_c_id)      // Logic ID  :14       
        {
            if (element_a_id == 13 && element_c_id == 35)
            {
                SaveLogic.Add(14);       //add this logic to savelogic 
            }
            return;
        }
        //Flag  Is Stop 13,32     Type: 123
        public static void Flag_Is_Stop(int element_a_id, int element_c_id)     //Logic ID  :15
        {
            if (element_a_id == 13 && element_c_id == 32)
            {
                SaveLogic.Add(15);       //add this logic to savelogic 
            }
        }

        //Flag  Is Rock 13,28     Type: 121
        public static void Flag_Is_Rock(int element_a_id, int element_c_id)     //Logic ID  :16
        {
            if (element_a_id == 13 && element_c_id == 28)
            {
                SaveLogic.Add(16);       //add this logic to savelogic 
            }
        }


        //Flag  Is Wall 13,33     Type: 121
        public static void Flag_Is_Wall(int element_a_id, int element_c_id)     //Logic ID  :17
        {
            if (element_a_id == 13 && element_c_id == 33)
            {
                SaveLogic.Add(17);       //add this logic to savelogic 
            }
        }

        //Type 121
        public static void Empty_Is_Flag(int element_a_id, int element_c_id)        //Logic ID: 18
        {
            if (element_a_id == 10 && element_c_id == 13)
            {
                SaveLogic.Add(18);       //add this logic to savelogic 
            }
        }

        public static void Empty_Is_Baba(int element_a_id, int element_c_id)         //Logic ID:19
        {
            if (element_a_id == 10 && element_c_id == 1)
            {
                SaveLogic.Add(19);       //add this logic to savelogic 
            }
        }
        //Type 123 water is sink  43,41
        public static void Water_Is_Sink(int element_a_id, int element_c_id)     //Logic ID  :20
        {
            if (element_a_id == 40 && element_c_id == 41)
            {
                SaveLogic.Add(20);       //add this logic to savelogic 
            }
        }

        //Type 123 Lava  Is Kill 21,20
        public static void Lava_Is_Kill(int element_a_id, int element_c_id)     //Logic ID  :21
        {
            if (element_a_id == 21 && element_c_id == 20)
            {
                SaveLogic.Add(21);       //add this logic to savelogic 
            }
        }

        //Type 123 Skull Is Kill 30,20
        public static void Skull_Is_Kill(int element_a_id, int element_c_id)    //Logic ID  :22
        {
            if (element_a_id == 30 && element_c_id == 20)
            {
                SaveLogic.Add(22);       //add this logic to savelogic 
            }
        }

        //Type 123 Grass Is Stop 38,32
        public static void Grass_Is_Stop(int element_a_id, int element_c_id)        //Logic ID  :23
        {
            if (element_a_id == 38 && element_c_id == 32)
            {
                SaveLogic.Add(23);       //add this logic to savelogic 
            }
        }

        //Type 123 Keke  Is Move 19,25
        public static void Keke_Is_Move(int element_a_id, int element_c_id)     //Logic ID  :24
        {
            if (element_a_id == 19 && element_c_id == 25)
            {
                SaveLogic.Add(24);       //add this logic to savelogic 
            }

        }

        //Flag is Push  13,27      Type: 123        25
        public static void Flag_Is_Push(int element_a_id, int element_c_id)     //Logic ID  :25
        {
            if (element_a_id == 13 && element_c_id == 27)
            {
                SaveLogic.Add(25);       //add this logic to savelogic 
            }
        }

        //Lava is Push  21,27      Type:123       26
        public static void Lava_Is_Push(int element_a_id, int element_c_id)     //Logic ID  :26
        {
            if (element_a_id == 21 && element_c_id == 27)
            {
                SaveLogic.Add(26);       //add this logic to savelogic 
            }
        }

        //Rock is Win   28,35       Type:123        27
        public static void Rock_Is_Win(int element_a_id, int element_c_id)     //Logic ID  :27
        {
            if (element_a_id == 28 && element_c_id == 35)
            {
                SaveLogic.Add(27);       //add this logic to savelogic 
            }
        }


        //Skull is Win  30,35       Type:123        28
        public static void Skull_Is_Win(int element_a_id, int element_c_id)     //Logic ID  :28
        {
            if (element_a_id == 30 && element_c_id == 35)
            {
                SaveLogic.Add(28);       //add this logic to savelogic 
            }
        }

        //Lava is Win   21,35       Type:123        29
        public static void Lava_Is_Win(int element_a_id, int element_c_id)     //Logic ID  :29
        {
            if (element_a_id == 21 && element_c_id == 35)
            {
                SaveLogic.Add(29);       //add this logic to savelogic 
            }
        }

        public static void Flag_Is_Kill(int element_a_id, int element_c_id)     //Logic ID  :31
        {
            if (element_a_id == 13 && element_c_id == 20)
            {
                SaveLogic.Add(31);       //add this logic to savelogic 
            }
        }
        public static void Rock_Is_Kill(int element_a_id, int element_c_id)     //Logic ID  :32
        {
            if (element_a_id == 28 && element_c_id == 20)
            {
                SaveLogic.Add(32);       //add this logic to savelogic 
            }
        }
        public static void Wall_Is_Kill(int element_a_id, int element_c_id)     //Logic ID  :33
        {
            if (element_a_id == 33 && element_c_id == 20)
            {
                SaveLogic.Add(33);       //add this logic to savelogic 
            }
        }
        public static void Ice_Is_Slip(int element_a_id, int element_c_id)     //Logic ID  :34
        {
            if (element_a_id == 17 && element_c_id == 31)
            {
                SaveLogic.Add(34);       //add this logic to savelogic 
            }
        }

        //Empty Is Win   10,35      Type:123        35
        public static void Empty_Is_Win(int element_a_id, int element_c_id)     //Logic ID  :35
        {
            if (element_a_id == 10 && element_c_id == 35)
            {
                SaveLogic.Add(35);       //add this logic to savelogic 
            }
        }
        public static void Empty_Is_Kill(int element_a_id, int element_c_id)     //Logic ID  :36
        {
            if (element_a_id == 10 && element_c_id == 20)
            {
                SaveLogic.Add(36);       //add this logic to savelogic 
            }
        }
        public static void Empty_Is_Rock(int element_a_id, int element_c_id)      //Empty Is Rock   10,28     Type:121        37
        {
            if (element_a_id == 10 && element_c_id == 28)
            {
                SaveLogic.Add(37);       //add this logic to savelogic 
            }
        }

        //Empty Is Wall   10,33     Type:121        38
        public static void Empty_Is_Wall(int element_a_id, int element_c_id)      //Empty Is Wall   10,33     Type:121        38
        {
            if (element_a_id == 10 && element_c_id == 33)
            {
                SaveLogic.Add(38);       //add this logic to savelogic 
            }
        }

        //Empty Is Skull  10,30     Type:121        39
        public static void Empty_Is_Skull(int element_a_id, int element_c_id)      //Empty Is Skull  10,30     Type:121        39
        {
            if (element_a_id == 10 && element_c_id == 30)
            {
                SaveLogic.Add(39);       //add this logic to savelogic 
            }
        }

        //Empty Is ICE   10,17        Logic ID:       40
        public static void Empty_Is_Ice(int element_a_id, int element_c_id)     //Empty Is ICE   10,17        Logic ID:       40
        {
            if (element_a_id == 10 && element_c_id == 17)
            {
                SaveLogic.Add(40);       //add this logic to savelogic 
            }
        }
        //Empty Is Keke  10,19        Logic ID:       41
        public static void Empty_Is_Keke(int element_a_id, int element_c_id)     //Empty Is Keke  10,19        Logic ID:       41
        {
            if (element_a_id == 10 && element_c_id == 19)
            {
                SaveLogic.Add(41);       //add this logic to savelogic 
            }
        }

        //Empty Is Lava  10,21        Logic ID:       42
        public static void Empty_Is_Lava(int element_a_id, int element_c_id)     //Empty Is Lava  10,21        Logic ID:       42
        {
            if (element_a_id == 10 && element_c_id == 21)
            {
                SaveLogic.Add(42);       //add this logic to savelogic 
            }
        }


        //Empty Is Grass 10,38        Logic ID:       43
        public static void Empty_Is_Grass(int element_a_id, int element_c_id)     //Empty Is Grass 10,38        Logic ID:       43
        {
            if (element_a_id == 10 && element_c_id == 38)
            {
                SaveLogic.Add(43);       //add this logic to savelogic 
            }
        }

        //Empty Is Love  10,39        Logic ID:       44
        public static void Empty_Is_Love(int element_a_id, int element_c_id)     //Empty Is Grass 10,38        Logic ID:       44
        {
            if (element_a_id == 10 && element_c_id == 39)
            {
                SaveLogic.Add(44);       //add this logic to savelogic 
            }
        }
        //Empty Is Goop  10,40        Logic ID:       45
        public static void Empty_Is_Goop(int element_a_id, int element_c_id)     //Empty Is Goop  10,40        Logic ID:       45
        {
            if (element_a_id == 10 && element_c_id == 40)
            {
                SaveLogic.Add(45);       //add this logic to savelogic 
            }
        }

        //Baba Is Empty 1,10        Logic ID:        46
        public static void Baba_Is_Empty(int element_a_id, int element_c_id)     //Empty Is Goop  10,40        Logic ID:       46
        {
            if (element_a_id == 1 && element_c_id == 10)
            {
                SaveLogic.Add(46);       //add this logic to savelogic 
            }
        }
        //Baba Is Flag  1,13        Logic ID:        47
        public static void Baba_Is_Flag(int element_a_id, int element_c_id)     //Empty Is Goop  10,40        Logic ID:       47
        {
            if (element_a_id == 1 && element_c_id == 13)
            {
                SaveLogic.Add(47);       //add this logic to savelogic 
            }
        }
        //Baba Is Ice   1,17       Logic ID:         48
        public static void Baba_Is_Ice(int element_a_id, int element_c_id)     //Baba Is Ice   1,17       Logic ID:         48
        {
            if (element_a_id == 1 && element_c_id == 17)
            {
                SaveLogic.Add(48);       //add this logic to savelogic 
            }
        }
        //Baba Is Keke  1,19        Logic ID:        49
        public static void Baba_Is_Keke(int element_a_id, int element_c_id)     //Baba Is Keke  1,19        Logic ID:        49
        {
            if (element_a_id == 1 && element_c_id == 19)
            {
                SaveLogic.Add(49);       //add this logic to savelogic 
            }
        }
        //Baba Is Lava  1,21        Logic ID:        50  
        public static void Baba_Is_Lava(int element_a_id, int element_c_id)    //Baba Is Lava  1,21        Logic ID:        50  
        {
            if (element_a_id == 1 && element_c_id == 21)
            {
                SaveLogic.Add(50);       //add this logic to savelogic 
            }
        }

        //Baba Is Skull 1,30        Logic ID:        51
        public static void Baba_Is_Skull(int element_a_id, int element_c_id)    //Baba Is Skull 1,30        Logic ID:        51
        {
            if (element_a_id == 1 && element_c_id == 30)
            {
                SaveLogic.Add(51);       //add this logic to savelogic 
            }
        }

        //Baba Is Grass 1,38        Logic ID:        53
        public static void Baba_Is_Grass(int element_a_id, int element_c_id)    //Baba Is Wall  1,33        Logic ID:        53
        {
            if (element_a_id == 1 && element_c_id == 38)
            {
                SaveLogic.Add(53);       //add this logic to savelogic 
            }
        }
        //Baba Is Love  1,39        Logic ID:        54
        public static void Baba_Is_Love(int element_a_id, int element_c_id)    //Baba Is Wall  1,33        Logic ID:        54
        {
            if (element_a_id == 1 && element_c_id == 39)
            {
                SaveLogic.Add(54);       //add this logic to savelogic 
            }
        }
        //Baba Is Goop  1,40        Logic ID:        55
        public static void Baba_Is_Goop(int element_a_id, int element_c_id)    //Baba Is Goop  1,40        Logic ID:        55
        {
            if (element_a_id == 1 && element_c_id == 40)
            {
                SaveLogic.Add(55);       //add this logic to savelogic 
            }
        }

      
        /// /////////////////////////////  86 start here
       
        /// <param name="element_a_id"></param>
        /// <param name="element_c_id"></param>
        //Rock Is Lava   28,21        Logic ID:       88
        public static void Rock_Is_Lava(int element_a_id, int element_c_id)   //Rock Is Lava   28,21        Logic ID:       88
        {
            if (element_a_id == 28 && element_c_id == 21)
            {
                SaveLogic.Add(88);       //add this logic to savelogic 
            }
        }
        //Rock Is Keke   28,19        Logic ID:       89
        public static void Rock_Is_Keke(int element_a_id, int element_c_id)  //Rock Is Keke   28,19        Logic ID:       89
        {
            if (element_a_id == 28 && element_c_id == 21)
            {
                SaveLogic.Add(89);       //add this logic to savelogic 
            }
        }

        //Rock Is Ice    28,17        Logic ID:       90
        public static void Rock_Is_Ice(int element_a_id, int element_c_id)  //Rock Is Ice    28,17        Logic ID:       90
        {
            if (element_a_id == 28 && element_c_id == 17)
            {
                SaveLogic.Add(90);       //add this logic to savelogic 
            }
        }
        //Rock Is Empty  28,10        Logic ID:       91
        public static void Rock_Is_Empty(int element_a_id, int element_c_id)  //Rock Is Empty  28,10        Logic ID:       91
        {
            if (element_a_id == 28 && element_c_id == 10)
            {
                SaveLogic.Add(91);       //add this logic to savelogic 
            }
        }
        //Rock Is Skull  28,30        Logic ID:       92 
        public static void Rock_Is_Skull(int element_a_id, int element_c_id)  //Rock Is Skull  28,30        Logic ID:       92
        {
            if (element_a_id == 28 && element_c_id == 30)
            {
                SaveLogic.Add(92);       //add this logic to savelogic 
            }
        }
        //Rock Is Grass  28,38        Logic ID:       94
        public static void Rock_Is_Grass(int element_a_id, int element_c_id)  //Rock Is Grass  28,38        Logic ID:       94
        {
            if (element_a_id == 28 && element_c_id == 38)
            {
                SaveLogic.Add(94);       //add this logic to savelogic 
            }
        }

        //Rock Is Love   28,39        Logic ID:       95
        public static void Rock_Is_Love(int element_a_id, int element_c_id)  //Rock Is Love   28,39        Logic ID:       95
        {
            if (element_a_id == 28 && element_c_id == 39)
            {
                SaveLogic.Add(95);       //add this logic to savelogic 
            }
        }
        //Rock Is Goop   28,40        Logic ID:       96
        public static void Rock_Is_Goop(int element_a_id, int element_c_id)  //Rock Is Goop   28,40        Logic ID:       96
        {
            if (element_a_id == 28 && element_c_id == 40)
            {
                SaveLogic.Add(96);       //add this logic to savelogic 
            }
        }


        //Skull Is Wall  30,33        Logic ID:       97
        public static void Skull_Is_Wall(int element_a_id, int element_c_id)  //Skull Is Wall  30,33        Logic ID:       97
        {
            if (element_a_id == 30 && element_c_id == 33)
            {
                SaveLogic.Add(97);       //add this logic to savelogic 
            }
        }
        //Skull Is Grass 30,38        Logic ID:       98
        public static void Skull_Is_Grass(int element_a_id, int element_c_id)  //Skull Is Grass 30,38        Logic ID:       98
        {
            if (element_a_id == 30 && element_c_id == 38)
            {
                SaveLogic.Add(98);       //add this logic to savelogic 
            }
        }
        //Skull Is Love  30,39        Logic ID:       99
        public static void Skull_Is_Love(int element_a_id, int element_c_id) //Skull Is Love  30,39        Logic ID:       99
        {
            if (element_a_id == 30 && element_c_id == 39)
            {
                SaveLogic.Add(99);       //add this logic to savelogic 
            }
        }
        //Skull Is Goop  30,40        Logic ID:       100
        public static void Skull_Is_Goop(int element_a_id, int element_c_id) //Skull Is Goop  30,40        Logic ID:       100
        {
            if (element_a_id == 30 && element_c_id == 40)
            {
                SaveLogic.Add(100);       //add this logic to savelogic 
            }
        }

        //Skull Is Rock  30,28        Logic ID:       101
        public static void Skull_Is_Rock(int element_a_id, int element_c_id) //Skull Is Rock  30,28        Logic ID:       101
        {
            if (element_a_id == 30 && element_c_id == 28)
            {
                SaveLogic.Add(101);       //add this logic to savelogic 
            }
        }
        //Skull Is Lava  30,21        Logic ID:       102
        public static void Skull_Is_Lava(int element_a_id, int element_c_id)  //Skull Is Lava  30,21        Logic ID:       102
        {
            if (element_a_id == 30 && element_c_id == 21)
            {
                SaveLogic.Add(102);       //add this logic to savelogic 
            }
        }
        //Skull Is Keke  30,19        Logic ID:       103
        public static void Skull_Is_Keke(int element_a_id, int element_c_id)  //Skull Is Keke  30,19        Logic ID:       103
        {
            if (element_a_id == 30 && element_c_id == 19)
            {
                SaveLogic.Add(103);       //add this logic to savelogic 
            }
        }
        //Skull Is Ice   30,17        Logic ID:       104
        public static void Skull_Is_Ice(int element_a_id, int element_c_id)  //Skull Is Ice   30,17        Logic ID:       104
        {
            if (element_a_id == 30 && element_c_id == 17)
            {
                SaveLogic.Add(104);       //add this logic to savelogic 
            }
        }
        //Skull Is Flag  30,13        Logic ID:       105
        public static void Skull_Is_Flag(int element_a_id, int element_c_id)  //Skull Is Flag  30,13        Logic ID:       105
        {
            if (element_a_id == 30 && element_c_id == 13)
            {
                SaveLogic.Add(105);       //add this logic to savelogic 
            }
        }
        //Skull Is Baba  30, 1       Logic ID:       106
        public static void Skull_Is_Baba(int element_a_id, int element_c_id)  //Skull Is Baba  30, 1       Logic ID:       106
        {
            if (element_a_id == 30 && element_c_id == 1)
            {
                SaveLogic.Add(106);       //add this logic to savelogic 
            }
        }
        //Skull Is Empty 30,10        Logic ID:       107
        public static void Skull_Is_Empty(int element_a_id, int element_c_id)  //Skull Is Empty 30,10        Logic ID:       107
        {
            if (element_a_id == 30 && element_c_id == 1)
            {
                SaveLogic.Add(107);       //add this logic to savelogic 
            }
        }

        //Wall Is Grass  33,38        Logic ID:       108
        public static void Wall_Is_Grass(int element_a_id, int element_c_id)  //Wall Is Grass  33,38        Logic ID:       108
        {
            if (element_a_id == 33 && element_c_id == 38)
            {
                SaveLogic.Add(108);       //add this logic to savelogic 
            }
        }
        //Wall Is Love   33,39        Logic ID:       109
        public static void Wall_Is_Love(int element_a_id, int element_c_id)  //Wall Is Love   33,39        Logic ID:       109
        {
            if (element_a_id == 33 && element_c_id == 39)
            {
                SaveLogic.Add(109);       //add this logic to savelogic 
            }
        }
        //Wall Is Goop   33,40        Logic ID:       110
        public static void Wall_Is_Goop(int element_a_id, int element_c_id)  //Wall Is Goop   33,40        Logic ID:       110
        {
            if (element_a_id == 33 && element_c_id == 40)
            {
                SaveLogic.Add(110);       //add this logic to savelogic 
            }
        }
        //Wall Is Rock   33,28        Logic ID:       111
        public static void Wall_Is_Rock(int element_a_id, int element_c_id)  //Wall Is Rock   33,28        Logic ID:       111
        {
            if (element_a_id == 33 && element_c_id == 28)
            {
                SaveLogic.Add(111);       //add this logic to savelogic 
            }
        }
        //Wall Is Lava   33,21        Logic ID:       112
        public static void Wall_Is_Lava(int element_a_id, int element_c_id)  //Wall Is Lava   33,21        Logic ID:       112
        {
            if (element_a_id == 33 && element_c_id == 21)
            {
                SaveLogic.Add(112);       //add this logic to savelogic 
            }
        }
        //Wall Is Keke   33,19       Logic ID:        113
        public static void Wall_Is_Keke(int element_a_id, int element_c_id)  //Wall Is Keke   33,19       Logic ID:        113
        {
            if (element_a_id == 33 && element_c_id == 19)
            {
                SaveLogic.Add(113);       //add this logic to savelogic 
            }
        }
        //Wall Is Ice    33,17        Logic ID:       114
        public static void Wall_Is_Ice(int element_a_id, int element_c_id)  //Wall Is Ice    33,17        Logic ID:       114
        {
            if (element_a_id == 33 && element_c_id == 17)
            {
                SaveLogic.Add(114);       //add this logic to savelogic 
            }
        }
        public static void Wall_Is_Baba(int element_a_id, int element_c_id)  //Wall Is Baba   33, 1       Logic ID:        115
        {
            if (element_a_id == 33 && element_c_id == 1)
            {
                SaveLogic.Add(115);       //add this logic to savelogic 
            }
        }
        public static void Wall_Is_Empty(int element_a_id, int element_c_id) //Wall Is Empty  33,10        Logic ID:       116
        {
            if (element_a_id == 33 && element_c_id == 10)
            {
                SaveLogic.Add(116);       //add this logic to savelogic 
            }
        }
        public static void Wall_Is_Skull(int element_a_id, int element_c_id) //Wall Is Skull  33,30        Logic ID:       117
        {
            if (element_a_id == 33 && element_c_id == 30)
            {
                SaveLogic.Add(117);       //add this logic to savelogic 
            }
        }

        public static void Lava_Is_Hot(int element_a_id, int element_c_id) //Lava Is Hot    21,16       Logic ID:       118
        {
            if (element_a_id == 21 && element_c_id == 16)
            {
                SaveLogic.Add(118);       //add this logic to savelogic 
            }
        }
        
        public static void Baba_Is_Melt(int element_a_id, int element_c_id) //Baba Is Melt   1,24        Logic ID:       119
        {
            if (element_a_id == 1 && element_c_id == 24)
            {
                SaveLogic.Add(119);       //add this logic to savelogic 
            }
        }

        //Goop  Is Hot   40,16        Logic ID:       120
        public static void Goop_Is_Hot(int element_a_id, int element_c_id) 
        {
            if (element_a_id == 40 && element_c_id == 16)
            {
                SaveLogic.Add(120);       //add this logic to savelogic 
            }
        }
        //Love  Is Hot   39,16        Logic ID:       121
        public static void Love_Is_Hot(int element_a_id, int element_c_id)
        {
            if (element_a_id == 39 && element_c_id == 16)
            {
                SaveLogic.Add(121);       //add this logic to savelogic 
            }
        }
        //Wall  Is Hot   33,16        Logic ID:       122
        public static void Wall_Is_Hot(int element_a_id, int element_c_id)
        {
            if (element_a_id == 33 && element_c_id == 16)
            {
                SaveLogic.Add(122);       //add this logic to savelogic 
            }
        }
        //Grass  Is Hot  38,16        Logic ID:       123      
        public static void Grass_Is_Hot(int element_a_id, int element_c_id)
        {
            if (element_a_id == 38 && element_c_id == 16)
            {
                SaveLogic.Add(123);       //add this logic to savelogic 
            }
        }
        //Rock  Is Hot   28,16        Logic ID:       124
        public static void Rock_Is_Hot(int element_a_id, int element_c_id)
        {
            if (element_a_id == 28 && element_c_id == 16)
            {
                SaveLogic.Add(124);       //add this logic to savelogic 
            }
        }

        //Keke  Is Hot   19,16        Logic ID:       126
        public static void Keke_Is_Hot(int element_a_id, int element_c_id)
        {
            if (element_a_id == 19 && element_c_id == 16)
            {
                SaveLogic.Add(126);       //add this logic to savelogic 
            }
        }
        //Ice  Is Hot    17,16        Logic ID:       127
        public static void Ice_Is_Hot(int element_a_id, int element_c_id)
        {
            if (element_a_id == 17 && element_c_id == 16)
            {
                SaveLogic.Add(127);       //add this logic to savelogic 
            }
        }
        //Flag  Is Hot   13,16        Logic ID:       128
        public static void Flag_Is_Hot(int element_a_id, int element_c_id)
        {
            if (element_a_id == 13 && element_c_id == 16)
            {
                SaveLogic.Add(128);       //add this logic to savelogic 
            }
        }
        //Baba  Is Hot   1,16         Logic ID:       129
        public static void Baba_Is_Hot(int element_a_id, int element_c_id)
        {
            if (element_a_id == 1 && element_c_id == 16)
            {
                SaveLogic.Add(129);       //add this logic to savelogic 
            }
        }
        //Empty  Is Hot  10,16        Logic ID:       130
        public static void Empty_Is_Hot(int element_a_id, int element_c_id)
        {
            if (element_a_id == 10 && element_c_id == 16)
            {
                SaveLogic.Add(130);       //add this logic to savelogic 
            }
        }
        //Skull  Is Hot  30,16        Logic ID:       131
        public static void Skull_Is_Hot(int element_a_id, int element_c_id)
        {
            if (element_a_id == 30 && element_c_id == 16)
            {
                SaveLogic.Add(131);       //add this logic to savelogic 
            }
        }

        //Goop  Is Melt   40,24        Logic ID:       132
        public static void Goop_Is_Melt(int element_a_id, int element_c_id)
        {
            if (element_a_id == 40 && element_c_id == 24)
            {
                SaveLogic.Add(132);       //add this logic to savelogic 
            }
        }
        //Love  Is Melt   39,24        Logic ID:       133
        public static void Love_Is_Melt(int element_a_id, int element_c_id)
        {
            if (element_a_id == 39 && element_c_id == 24)
            {
                SaveLogic.Add(133);       //add this logic to savelogic 
            }
        }
        //Wall  Is Melt   33,24        Logic ID:       134
        public static void Wall_Is_Melt(int element_a_id, int element_c_id)
        {
            if (element_a_id == 33 && element_c_id == 24)
            {
                SaveLogic.Add(134);       //add this logic to savelogic 
            }
        }
        //Grass  Is Melt  38,24        Logic ID:       135
        public static void Grass_Is_Melt(int element_a_id, int element_c_id)
        {
            if (element_a_id == 38 && element_c_id == 24)
            {
                SaveLogic.Add(135);       //add this logic to savelogic 
            }
        }
        //Rock  Is Melt   28,24        Logic ID:       136
        public static void Rock_Is_Melt(int element_a_id, int element_c_id)
        {
            if (element_a_id == 28 && element_c_id == 24)
            {
                SaveLogic.Add(136);       //add this logic to savelogic 
            }
        }
        //Lava  Is Melt   21,24        Logic ID:       137
        public static void Lava_Is_Melt(int element_a_id, int element_c_id)
        {
            if (element_a_id == 21 && element_c_id == 24)
            {
                SaveLogic.Add(137);       //add this logic to savelogic 
            }
        }
        //Keke  Is Melt   19,24        Logic ID:       138
        public static void Keke_Is_Melt(int element_a_id, int element_c_id)
        {
            if (element_a_id == 19 && element_c_id == 24)
            {
                SaveLogic.Add(138);       //add this logic to savelogic 
            }
        }
        //Ice  Is Melt    17,24        Logic ID:       139
        public static void Ice_Is_Melt(int element_a_id, int element_c_id)
        {
            if (element_a_id == 17 && element_c_id == 24)
            {
                SaveLogic.Add(139);       //add this logic to savelogic 
            }
        }
        //Flag  Is Melt   13,24        Logic ID:       140
        public static void Flag_Is_Melt(int element_a_id, int element_c_id)
        {
            if (element_a_id == 13 && element_c_id == 24)
            {
                SaveLogic.Add(140);       //add this logic to savelogic 
            }
        }
        //Empty  Is Melt  10,24        Logic ID:       141
        public static void Empty_Is_Melt(int element_a_id, int element_c_id)
        {
            if (element_a_id == 10 && element_c_id == 24)
            {
                SaveLogic.Add(141);       //add this logic to savelogic 
            }
        }
        //Skull  Is Melt  30,24        Logic ID:       142
        public static void Skull_Is_Melt(int element_a_id, int element_c_id)
        {
            if (element_a_id == 30 && element_c_id == 24)
            {
                SaveLogic.Add(142);       //add this logic to savelogic 
            }
        }

        //Empty Is Slip  10,31        Logic ID:       143
        public static void Empty_Is_Slip(int element_a_id, int element_c_id)
        {
            if (element_a_id == 10 && element_c_id == 31)
            {
                SaveLogic.Add(143);       //add this logic to savelogic 
            }
        }

        //Flag Is Slip   13,31        Logic ID:       144
        public static void Flag_Is_Slip(int element_a_id, int element_c_id)
        {
            if (element_a_id == 13 && element_c_id == 31)
            {
                SaveLogic.Add(144);       //add this logic to savelogic 
            }
        }
    }

}
﻿using System;
using System.IO;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;


namespace mapdemo2
{
    class GameObject
    {
        public int id { get; set; }
        public int num { get; set; }//1 represent Object_name, 2 represent "is"，3 represent Object_logic , 0

        public bool stop { get; set; }//stop = not-accessible  eg empty_obj is treu
        public bool pushable { get; set; }//represents movable  eg. empty_obj is false, Rock is Push-> Rock_obj is true
        public bool isdie { get; set; }//player touch it die or not     default is false!  kill,sink,hot,defeat 都属于kill的情况
        public bool ispass { get; set; }//palyer touch it and pass this game level   default is false!
        public bool isslip { get; set; }//ice is slip or not 只能前进一个方向

        public bool issink { get; set; }
        public bool keke_ismove { get; set; }//true代表会自动移动____人物属性(Keke )有一关keke会自动移动 默认true
        public int keke_direction { get; set; }//1表示上 2表示下 3表示左 4表示右____人物属性（keke） 默认3

        public bool ismelt { get; set; }
        public bool ishot { get; set; }


        public int slip_direction;  // 1 ↑，2 ↓，3 ←，4 →，0 无，默认0

        //constructor here!
        //this version constructor have all arguments
        public GameObject(int Id, bool Stop, bool Pushable, int Num, bool Isslip = false, bool Isdie = false, bool Ispass = false, bool Keke_ismove = false, int keke_direction = 3, bool issink = false, bool ismelt=false,bool ishot = false)
        {

            this.id = Id;
            this.stop = Stop;
            this.pushable = Pushable;
            this.num = Num;
            this.isdie = Isdie;
            this.ispass = Ispass;
            this.isslip = Isslip;
            this.keke_ismove = Keke_ismove;
            this.keke_direction = keke_direction;
            this.issink = issink;
            this.ismelt = ismelt;
            this.ishot = ishot;
        }

        //this  constructor without keke,but related to game win/lose
        public GameObject(int Id, bool Stop, bool Pushable, bool Isslip, bool Isdie = false, bool Ispass = false)
        {
            this.id = Id;
            this.stop = Stop;
            this.pushable = Pushable;
            this.isdie = Isdie;
            this.ispass = Ispass;
            this.isslip = Isslip;
        }

        //this  construcot without keke and game win/lose related element,use for ice

        public GameObject(int Id, bool Stop, bool Pushable, bool Isslip)
        {
            this.id = Id;
            this.stop = Stop;
            this.pushable = Pushable;
            this.isslip = Isslip;
        }

        //this  construtor with keke,ice_slip, win/lsoe element
        public GameObject(int Id, bool Stop, bool Pushable)
        {
            this.id = Id;
            this.stop = Stop;
            this.pushable = Pushable;
        }

        //this construtir only have name and id
        public GameObject(int Id)
        {
            this.id = Id;
        }

        //this construtor that you after declare, you change element property one by one
        public GameObject()
        {

        }

        public int Posx { get; set; }
        public int Posy { get; set; }

    }
}


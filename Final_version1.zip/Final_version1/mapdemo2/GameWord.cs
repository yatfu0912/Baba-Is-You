﻿using System;
using System.IO;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace mapdemo2
{
    class GameWord
    {
        public bool destructible;  //可否销毁  eg碰上 Lava_obj 的时候word可以被销毁
        public bool iswin; //123 练成是否win eg Baba is Win then it becomes true
        public int Num;//1代表主体， 2代表is（即判断词），3代表主体属性____逻辑单词属性

        public GameWord( int Num, bool iswin, bool destructible)        //constructor here!
        {            
            this.Num = Num;            // Define Object_name is 1,  "is" is 2,  game object properties is 3
            this.iswin = iswin;        //Define player can win by touch the object
            this.destructible = destructible;  //Define Word is pushable always true

        }


        //this construtor that you after declare, you change element property one by one
        public GameWord()
        {

        }

        public int Posx { get; set; }
        public int Posy { get; set; }
    }
}

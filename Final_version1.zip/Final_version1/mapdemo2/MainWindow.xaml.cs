﻿using System;
using System.IO;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using static mapdemo2.GameObject;           //this used to access GameObject Method
using static mapdemo2.GameMethod;
using System.Drawing;
using System.Windows.Controls;

namespace mapdemo2
{
    /// <summary>
    /// MainWindow.xaml 的交互逻辑
    /// </summary>
    /// 

    public partial class MainWindow : Window
    {

        public BitmapImage bmp0 = new BitmapImage(new Uri("/Image/0.bmp", UriKind.Relative));          //  0 :empty_obj
        public BitmapImage bmp1 = new BitmapImage(new Uri("/Image/1.bmp", UriKind.Relative));               //  1 :baba
        public BitmapImage bmp2 = new BitmapImage(new Uri("/Image/2.bmp", UriKind.Relative));                 //  2 :is
        public BitmapImage bmp3 = new BitmapImage(new Uri("/Image/3.bmp", UriKind.Relative));                //  3 :you
        public BitmapImage bmp4 = new BitmapImage(new Uri("/Image/4.bmp", UriKind.Relative));             //  4 :player
        public BitmapImage bmp5 = new BitmapImage(new Uri("/Image/5.bmp", UriKind.Relative));        //  5 :wall_middle
        public BitmapImage bmp6 = new BitmapImage(new Uri("/Image/6.bmp", UriKind.Relative));     //  6 :wall_left_down
        public BitmapImage bmp7 = new BitmapImage(new Uri("/Image/7.bmp", UriKind.Relative));      //  7 :wall_left_top
        public BitmapImage bmp8 = new BitmapImage(new Uri("/Image/8.bmp", UriKind.Relative));    //  8 :wall_right_down
        public BitmapImage bmp9 = new BitmapImage(new Uri("/Image/9.bmp", UriKind.Relative));     //  9 :wall_right_top
        public BitmapImage bmp10 = new BitmapImage(new Uri("/Image/10.bmp", UriKind.Relative));             //  10:empty
        public BitmapImage bmp11 = new BitmapImage(new Uri("/Image/11.bmp", UriKind.Relative));             // 11:defeat
        public BitmapImage bmp12 = new BitmapImage(new Uri("/Image/12.bmp", UriKind.Relative));       //  12:baba_in_ice
        public BitmapImage bmp13 = new BitmapImage(new Uri("/Image/13.bmp", UriKind.Relative));              //  13:flag
        public BitmapImage bmp14 = new BitmapImage(new Uri("/Image/14.bmp", UriKind.Relative));          //  14:flag_obj
        public BitmapImage bmp15 = new BitmapImage(new Uri("/Image/15.bmp", UriKind.Relative));         //  15:grass_obj
        public BitmapImage bmp16 = new BitmapImage(new Uri("/Image/16.bmp", UriKind.Relative));               //  16:hot
        public BitmapImage bmp17 = new BitmapImage(new Uri("/Image/17.bmp", UriKind.Relative));               //  17:ice
        public BitmapImage bmp18 = new BitmapImage(new Uri("/Image/18.bmp", UriKind.Relative));           //  18:ice_obj
        public BitmapImage bmp19 = new BitmapImage(new Uri("/Image/19.bmp", UriKind.Relative));              //  19:keke
        public BitmapImage bmp20 = new BitmapImage(new Uri("/Image/20.bmp", UriKind.Relative));              //  20:kill
        public BitmapImage bmp21 = new BitmapImage(new Uri("/Image/21.bmp", UriKind.Relative));              //  21:lava
        public BitmapImage bmp22 = new BitmapImage(new Uri("/Image/22.bmp", UriKind.Relative));          //  22:keke_obj
        public BitmapImage bmp23 = new BitmapImage(new Uri("/Image/23.bmp", UriKind.Relative));          //  23:love_obj
        public BitmapImage bmp24 = new BitmapImage(new Uri("/Image/24.bmp", UriKind.Relative));              //  24:melt
        public BitmapImage bmp25 = new BitmapImage(new Uri("/Image/25.bmp", UriKind.Relative));              //  25:move
        public BitmapImage bmp26 = new BitmapImage(new Uri("/Image/26.bmp", UriKind.Relative));    //  26:player_in_wall
        public BitmapImage bmp27 = new BitmapImage(new Uri("/Image/27.bmp", UriKind.Relative));              //  27:push
        public BitmapImage bmp28 = new BitmapImage(new Uri("/Image/28.bmp", UriKind.Relative));              //  28:rock
        public BitmapImage bmp29 = new BitmapImage(new Uri("/Image/29.bmp", UriKind.Relative));          //  29:rock_obj
        public BitmapImage bmp30 = new BitmapImage(new Uri("/Image/30.bmp", UriKind.Relative));             //  30:Skull
        public BitmapImage bmp31 = new BitmapImage(new Uri("/Image/31.bmp", UriKind.Relative));              //  31:slip
        public BitmapImage bmp32 = new BitmapImage(new Uri("/Image/32.bmp", UriKind.Relative));              //  32:stop
        public BitmapImage bmp33 = new BitmapImage(new Uri("/Image/33.bmp", UriKind.Relative));              //  33:wall
        public BitmapImage bmp34 = new BitmapImage(new Uri("/Image/34.bmp", UriKind.Relative));         //  34:water_obj
        public BitmapImage bmp35 = new BitmapImage(new Uri("/Image/35.bmp", UriKind.Relative));               //  35:win
        public BitmapImage bmp36 = new BitmapImage(new Uri("/Image/36.bmp", UriKind.Relative));          //  36:lava_obj
        public BitmapImage bmp37 = new BitmapImage(new Uri("/Image/37.bmp", UriKind.Relative));     //  37:wall_vertical
        public BitmapImage bmp38 = new BitmapImage(new Uri("/Image/38.bmp", UriKind.Relative));             //  38:grass
        public BitmapImage bmp39 = new BitmapImage(new Uri("/Image/39.bmp", UriKind.Relative));              //  39:love
        public BitmapImage bmp40 = new BitmapImage(new Uri("/Image/40.bmp", UriKind.Relative));              //  40:goop
        public BitmapImage bmp41 = new BitmapImage(new Uri("/Image/41.bmp", UriKind.Relative));              //  41:sink
        public BitmapImage bmp42 = new BitmapImage(new Uri("/Image/42.bmp", UriKind.Relative));         //  42:skull_obj
        public BitmapImage bmp43 = new BitmapImage(new Uri("/Image/43.bmp", UriKind.Relative));         //  42:water

        public List<string> id_num = new List<string>();
        
        private void add_id_num()
        {
            id_num.Add("   ");
            id_num.Add("BA");
            id_num.Add("IS");
            id_num.Add("YO");
            id_num.Add("ba ");
            id_num.Add("ww ");
            id_num.Add("1 ");
            id_num.Add("2 ");
            id_num.Add("3 ");
            id_num.Add("4 ");
            id_num.Add("EP");
            id_num.Add("DE");
            id_num.Add("5");
            id_num.Add("FL");
            id_num.Add("fl ");
            id_num.Add("gr ");
            id_num.Add("HO");
            id_num.Add("IC");
            id_num.Add("ic ");
            id_num.Add("KE");
            id_num.Add("KI");
            id_num.Add("LA");
            id_num.Add("ke ");
            id_num.Add("lo ");
            id_num.Add("ME");
            id_num.Add("MO");
            id_num.Add("6");
            id_num.Add("PU");
            id_num.Add("RO");
            id_num.Add("ro ");
            id_num.Add("SK");
            id_num.Add("SL");
            id_num.Add("ST");
            id_num.Add("WW");//wall
            id_num.Add("wa ");//water
            id_num.Add("WI");
            id_num.Add("la ");
            id_num.Add("7");
            id_num.Add("GR");
            id_num.Add("LO");
            id_num.Add("GO");
            id_num.Add("SI");
            id_num.Add("sk ");
            id_num.Add("WA");

        }

        private List<BitmapImage> BitmapImageList; // Store all the images

        //    private int[,] NumberMatrix = new int[20, 20]; // The number matrix: model of the map
        //    private static List<int[,]> NumberMatrixList; // Store the  matrices of all maps       update 
        //    private Image[,] ImageMatrix = new Image[20, 20]; // Store image matrix, for all the block image shown in the view
        //    private List<Image[,]> ImageMatrixList; // Store the images shown in all  maps       update        // not used at all

        //记录IMAGE LIST
        private List<Image> Imagelist = new List<Image>();


        public static List<int> player_id = new List<int>(); // id of the current player
        public static List<gameboard> board_list = new List<gameboard>(); // list of gameboard
        private int ImageSize;
        private static int CurrentMap; // Decide which map we are now, decide whether to change to the next map
        private bool Initailized = false; // Initialization parameter, to prevent unexpected error
                                          //    private int[,] CurrentNum_Matrix = new int[20, 20]; // the current number matrix ;
                                          //新的方案： 
                                          //     一个LIST 记录每一步的控制的角色ID
                                          //   GAME BOARD 如下

        //variable that store current statement make what condition happen
        public static bool win_state = false;
        public static bool lose_state = false;
        public static int lava_state = 0;
        public static List<int> hot_state = new List<int>();

        public static int gamelevel = 0;

        public static  List<int> first_id = new List<int>();
        public static  List<int> second_id = new List<int>();

        public bool check_move(int id)
        {
            foreach (var element in GameObjectList)
                if (element.id == id && element.keke_ismove == true)
                    return true;
            return false;
        }

        public int move_direction(int id)
        {
            foreach (var element in GameObjectList)
                if (element.id == id)
                    return element.keke_direction;
            return 0;
        }

        public void change_move_direction(int id, int direction)
        {
            foreach (var element in GameObjectList)
                if (element.id == id)
                {
                    element.keke_direction = direction;
                    return;
                }
            return;
        }
        List<int> move_x = new List<int>();
        List<int> move_y = new List<int>();
        private void Move_object_move(gameboard tempboard)
        {
            //MessageBox.Show("TEsting!");
            int num1 = move_x.Count;
            for (int n = 0; n < num1; n++)
            {
                int i = move_x[n];
                int j = move_y[n];
                int num = tempboard.boardpos[i, j].pos.Count;
                for (int k = 0; k < num; k++)
                {
                    int id = tempboard.boardpos[i, j].pos[k];
                    if (check_move(id))
                    {
                        int direction = move_direction(id); // 1 上， 2 下， 3 左， 4 右
                        switch (direction)
                        {
                            case 1: // up
                                int move_type1 = Check_up(i - 1, j, tempboard, 0);
                                switch (move_type1)
                                {
                                    case 1:
                                      //  MessageBox.Show("TEsting! case 1-1 x:" + i.ToString() + "y:" + j.ToString());
                                        change_move_direction(id, 2);
                                        int t11 = Check_down(i + 1, j, tempboard, 0);
                                        switch (t11)
                                        {
                                            case 1:
                                                break;
                                            case 2:
                                            //    MessageBox.Show("TEsting! case 1-1-2 x:" + i.ToString() + "y:" + j.ToString());
                                                draw_push_down(i + 1, j, tempboard);
                                                tempboard.boardpos[i, j].pos.Remove(id);
                                                tempboard.boardpos[i + 1, j].pos.Add(id);
                                                move_x[n]++;
                                                break;
                                            case 3:
                                              //  MessageBox.Show("TEsting! case 1-1-3 x:" + i.ToString() + "y:" + j.ToString());
                                                tempboard.boardpos[i, j].pos.Remove(id);
                                                tempboard.boardpos[i + 1, j].pos.Add(id);
                                                move_x[n]++;
                                                break;
                                        }

                                        break;
                                    case 2:
                                        draw_push_up(i - 1, j, tempboard);
                                        tempboard.boardpos[i, j].pos.Remove(id);
                                        tempboard.boardpos[i - 1, j].pos.Add(id);
                                        move_x[n]--;
                                        break;
                                    case 3:// this is simply move ,不过可能还有触发逻辑
                                        tempboard.boardpos[i, j].pos.Remove(id);
                                        tempboard.boardpos[i - 1, j].pos.Add(id);
                                        move_x[n]--;
                                        break;
                                }

                                break;
                            case 2:
                                int move_type2 = Check_down(i + 1, j, tempboard, 0);
                                switch (move_type2)
                                {
                                    case 1:
                                      //  MessageBox.Show("TEsting! case 2-1 x:" + i.ToString() + "y:" + j.ToString());
                                        change_move_direction(id, 1);
                                        int t21 = Check_up(i - 1, j, tempboard, 0);
                                        switch (t21)
                                        {
                                            case 1:
                                                break;
                                            case 2:
                                            //    MessageBox.Show("TEsting! case 2-1-2 x:" + i.ToString() + "y:" + j.ToString());
                                                draw_push_up(i - 1, j, tempboard);
                                                tempboard.boardpos[i, j].pos.Remove(id);
                                                tempboard.boardpos[i - 1, j].pos.Add(id);
                                                move_x[n]--;
                                                break;
                                            case 3:
                                             //   MessageBox.Show("TEsting! case 2-1-3 x:" + i.ToString() + "y:" + j.ToString());
                                                tempboard.boardpos[i, j].pos.Remove(id);
                                                tempboard.boardpos[i - 1, j].pos.Add(id);
                                                move_x[n]--;
                                                break;
                                        }

                                        break;
                                    case 2:
                                      //  MessageBox.Show("TEsting! case 2-2 x:" + i.ToString() + "y:" + j.ToString());
                                        draw_push_down(i + 1, j, tempboard);
                                        tempboard.boardpos[i, j].pos.Remove(id);
                                        tempboard.boardpos[i + 1, j].pos.Add(id);
                                        move_x[n]++;
                                        break;
                                    case 3:// this is simply move ,不过可能还有触发逻辑
                                    //    MessageBox.Show("TEsting! case 2-3 x:" + i.ToString() + "y:" + j.ToString());
                                        tempboard.boardpos[i, j].pos.Remove(id);
                                        tempboard.boardpos[i + 1, j].pos.Add(id);
                                        move_x[n]++;
                                        break;
                                }

                                break;
                            case 3:
                                int move_type3 = Check_left(i, j - 1, tempboard, 0);
                                switch (move_type3)
                                {
                                    case 1:
                                        change_move_direction(id, 4);
                                        int t31 = Check_right(i, j + 1, tempboard, 0);
                                        switch (t31)
                                        {
                                            case 1:
                                                break;
                                            case 2:
                                           //     MessageBox.Show("TEsting! case 3-1-2 x:" + i.ToString() + "y:" + j.ToString());
                                                draw_push_right(i, j + 1, tempboard);
                                                tempboard.boardpos[i, j].pos.Remove(id);
                                                tempboard.boardpos[i, j + 1].pos.Add(id);
                                                move_y[n]++;
                                                break;
                                            case 3:
                                           //     MessageBox.Show("TEsting! case 3-1-3 x:" + i.ToString() + "y:" + j.ToString());
                                                tempboard.boardpos[i, j].pos.Remove(id);
                                                tempboard.boardpos[i, j + 1].pos.Add(id);
                                                move_y[n]++;
                                                break;
                                        }
                                        // do nothing now, since no move
                                        break;
                                    case 2:
                                        draw_push_left(i, j - 1, tempboard);
                                        tempboard.boardpos[i, j].pos.Remove(id);
                                        tempboard.boardpos[i, j - 1].pos.Add(id);
                                        move_y[n]--;
                                        break;
                                    case 3:// this is simply move ,不过可能还有触发逻辑
                                        tempboard.boardpos[i, j].pos.Remove(id);
                                        tempboard.boardpos[i, j - 1].pos.Add(id);
                                        move_y[n]--;
                                        break;
                                }


                                break;
                            case 4:
                                int move_type4 = Check_right(i, j + 1, tempboard, 0);
                                switch (move_type4)
                                {
                                    case 1:
                                        change_move_direction(id, 3);
                                        int t31 = Check_left(i, j - 1, tempboard, 0);
                                        switch (t31)
                                        {
                                            case 1:
                                                break;
                                            case 2:
                                              //  MessageBox.Show("TEsting! case 4-1-2 x:" + i.ToString() + "y:" + j.ToString());
                                                draw_push_right(i, j - 1, tempboard);
                                                tempboard.boardpos[i, j].pos.Remove(id);
                                                tempboard.boardpos[i, j - 1].pos.Add(id);
                                                move_y[n]--;
                                                break;
                                            case 3:
                                            //    MessageBox.Show("TEsting! case 4-1-3 x:" + i.ToString() + "y:" + j.ToString());
                                                tempboard.boardpos[i, j].pos.Remove(id);
                                                tempboard.boardpos[i, j - 1].pos.Add(id);
                                                move_y[n]--;
                                                break;
                                        }
                                        // do nothing now, since no move
                                        break;
                                    case 2:
                                        draw_push_right(i, j + 1, tempboard);
                                        move_y[n]++;
                                        break;
                                    case 3:// this is simply move ,不过可能还有触发逻辑
                                        tempboard.boardpos[i, j].pos.Remove(id);
                                        tempboard.boardpos[i, j + 1].pos.Add(id);
                                        move_y[n]++;
                                        break;
                                }

                                break;


                        }

                    }
                }
            }






        }


        public class position
        {
            public List<int> pos = new List<int>();
            public position()
            {
            }
        }
        public class gameboard
        {
            public position[,] boardpos = new position[20, 20];
            public gameboard()
            {
                for (int i = 0; i < 20; i++)
                {
                    for (int j = 0; j < 20; j++)
                    {
                        position temp = new position();
                        this.boardpos[i, j] = temp;
                    }
                }
            }
        }

        /*示例：

        gameboard board = new gameboard();
        board.board[0, 0].numlist.Add(1);
			Console.WriteLine("{0}",board.board[0, 0].numlist[0]);*/



        //public GameObject(int Id, bool Accessable, bool Pushable, int num,bool Isslip = false, bool Isdie = false, bool Ispass = false, bool Keke_ismove = true, int keke_direction = 3)


        //clear the tempboard for further use.




        // update the current map to the currentnum_matrix
        public void Startup() // General Initialization
        {
            BitmapImageList = new List<BitmapImage>();

            StoreBitmap();

            add_id_num();

            CurrentMap = 0;

            ImageSize = 40;

            player_id.Add(4); // first player is 4: baba_object

            InitailizeMap(); //draw the first map

            Initailized = true;

            return;

        }

        // 每次 TEMPBOARD 每个格子第一个都是EMPTY. 如果不复制其他棋盘则CALL这个函数
        private void initial_temp(gameboard tempgameboard)
        {
            for (int i = 0; i < 20; i++)
            {
                for (int j = 0; j < 20; j++)
                    tempgameboard.boardpos[i, j].pos.Add(0);
            }
        }

        private void cp_temp(gameboard tempgameboard) // copy the current board to tempboard
        {
            for (int i = 0; i < 20; i++)
            {
                for (int j = 0; j < 20; j++)
                {
                    foreach (int id in board_list[CurrentMap].boardpos[i, j].pos)
                        tempgameboard.boardpos[i, j].pos.Add(id);
                }
            }
        }

        public void InitailizeMap() // Draw all the blocks in map, according to different number appearing in the number matrix
        {

            gameboard tempgameboard = new gameboard(); // tempboard
            initial_temp(tempgameboard);
            for (int i = 0; i < 20; i++) //画15
            {
                tempgameboard.boardpos[19, i].pos.Add(15);
                tempgameboard.boardpos[0, i].pos.Add(15);
            }
            for (int i = 1; i < 19; i++) //画15
            {
                tempgameboard.boardpos[i, 0].pos.Add(15);
                tempgameboard.boardpos[i, 19].pos.Add(15);
            }
            /*   for (int i = 4; i < 16; i++) //画5
               {
                   tempgameboard.boardpos[7, i].pos.Add(5);
                   tempgameboard.boardpos[11, i].pos.Add(5);
               }*/

            //Baba  Is Win   1,35     Type: 123

            //画is
            tempgameboard.boardpos[5, 6].pos.Add(2);
            //draw wall
            tempgameboard.boardpos[5, 13].pos.Add(5);

            //draw is
            tempgameboard.boardpos[13, 6].pos.Add(2);
            tempgameboard.boardpos[13, 13].pos.Add(2);
            //画 baba
            tempgameboard.boardpos[5, 5].pos.Add(1);
            //画 win
            tempgameboard.boardpos[4, 7].pos.Add(35);
            //画baba word
            tempgameboard.boardpos[5, 12].pos.Add(1);
            //画win
            tempgameboard.boardpos[5, 14].pos.Add(35);
            //画BABA_OBJECT
            tempgameboard.boardpos[9, 7].pos.Add(4);
            //画ROCK_OBJET
            tempgameboard.boardpos[9, 10].pos.Add(18);
            tempgameboard.boardpos[8, 10].pos.Add(18);
            tempgameboard.boardpos[10, 10].pos.Add(18);
            tempgameboard.boardpos[9, 11].pos.Add(18);
            //画BABA
            tempgameboard.boardpos[13, 5].pos.Add(1);
            //画YOU
            tempgameboard.boardpos[13, 7].pos.Add(3);
            //画FLAG
            tempgameboard.boardpos[12, 12].pos.Add(13);
            //画WIN
            tempgameboard.boardpos[13, 14].pos.Add(35);

            //draw flag_obj
            tempgameboard.boardpos[14, 8].pos.Add(14);  //flag obj id is 14

            //draw skull is kill and skull obj
            tempgameboard.boardpos[13, 12].pos.Add(30);
            tempgameboard.boardpos[14, 13].pos.Add(2);
            tempgameboard.boardpos[14, 14].pos.Add(20);
            tempgameboard.boardpos[14, 15].pos.Add(42); //skull obj 
            tempgameboard.boardpos[14, 16].pos.Add(29); //rock obj 


            //draw Rock is push 28,2,27
            tempgameboard.boardpos[3, 6].pos.Add(28);
            tempgameboard.boardpos[3, 7].pos.Add(2);
            tempgameboard.boardpos[2, 8].pos.Add(27);

            //draw rock is stop
            tempgameboard.boardpos[1, 1].pos.Add(28);
            tempgameboard.boardpos[1, 2].pos.Add(2);
            //tempgameboard.boardpos[1, 3].pos.Add(32);
            //draw wall is stop
            tempgameboard.boardpos[2, 1].pos.Add(33);
            tempgameboard.boardpos[2, 2].pos.Add(2);
            tempgameboard.boardpos[2, 3].pos.Add(32);

            //draw goop is sink and water obj
            tempgameboard.boardpos[12, 4].pos.Add(40);
            tempgameboard.boardpos[12, 5].pos.Add(2);
            tempgameboard.boardpos[12, 6].pos.Add(41);
            tempgameboard.boardpos[12, 8].pos.Add(34);

            //draw baba is rock ,wall 
            tempgameboard.boardpos[17, 2].pos.Add(1);
            tempgameboard.boardpos[17, 3].pos.Add(2);
            tempgameboard.boardpos[16, 4].pos.Add(28);
            tempgameboard.boardpos[17, 5].pos.Add(33);

            //draw lava is hot and baba is melt and lava obj
            tempgameboard.boardpos[2, 12].pos.Add(21);    //lava
            tempgameboard.boardpos[2, 13].pos.Add(2);    //is 
            tempgameboard.boardpos[1, 14].pos.Add(16);   //hot
            tempgameboard.boardpos[2, 15].pos.Add(36);   //lava obj
            tempgameboard.boardpos[3, 2].pos.Add(1);     //baba
            tempgameboard.boardpos[3, 3].pos.Add(2);     //is
            tempgameboard.boardpos[3, 4].pos.Add(24);    //melt
            tempgameboard.boardpos[3, 5].pos.Add(36);    //lava obj

            //draw ice is slip
            tempgameboard.boardpos[8, 1].pos.Add(17);    //ice
            tempgameboard.boardpos[8, 2].pos.Add(2);    //is 
            tempgameboard.boardpos[8, 3].pos.Add(31);   //slip

            //drae empty word
            tempgameboard.boardpos[8, 13].pos.Add(10);   //slip


            //加入BOARD LIST
            board_list.Add(tempgameboard);
            DrawMap();

        }

        //RETURN X, Y 位置最后一个元素的ID
        public static int return_id(gameboard tempboard, int x, int y)
        {
            return tempboard.boardpos[x, y].pos.Last();
        }

        

        public static void vertical_logic(gameboard tempboard)
        {
            for (int i = 0; i < 18; i++)
            {
                for (int j = 0; j < 19; j++)
                {
                    foreach (var element_a in GameObjectList)
                    {
                        if (return_id(tempboard, i, j) == element_a.id && element_a.num == 1)
                        {
                            foreach (var element_b in GameObjectList)
                            {
                                if (return_id(tempboard, i + 1, j) == element_b.id && element_b.num == 2)
                                {
                                    foreach (var element_c in GameObjectList)
                                    {
                                        //consider basic type of 123
                                        if (return_id(tempboard, i + 2, j) == element_c.id && element_c.num == 3)
                                        {
                                            Call_All_Statement_123(element_a.id, element_c.id);
                                        }
                                        //consider type of 121  eg Baba is wall
                                        if (return_id(tempboard, i + 2, j) == element_c.id && element_c.num == 1)
                                        {
                                            Call_All_Statement_121(element_a.id, element_c.id);
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }




        public static void horizontal_logic(gameboard tempboard)
        {
            for (int i = 0; i < 19; i++)
            {
                for (int j = 0; j < 18; j++)
                {
                    foreach (var element_a in GameObjectList)
                    {
                        if (return_id(tempboard, i, j) == element_a.id && element_a.num == 1)
                        {
                            foreach (var element_b in GameObjectList)
                            {
                                if (return_id(tempboard, i, j + 1) == element_b.id && element_b.num == 2)
                                {
                                    foreach (var element_c in GameObjectList)
                                    {
                                        //consider basic type of 123
                                        if (return_id(tempboard, i, j + 2) == element_c.id && element_c.num == 3)
                                        {
                                            Call_All_Statement_123(element_a.id, element_c.id);
                                        }
                                        //consider type of 121  eg Baba is wall
                                        if (return_id(tempboard, i, j + 2) == element_c.id && element_c.num == 1)
                                        {
                                            Call_All_Statement_121(element_a.id, element_c.id);
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
        public int map = -1;
        //if map == 0, 就是画带图案的， map == 1， 画TEXTBLOCK里面
        public void DrawMap() // DarwMap function in detailed location    //now just will draw the whole map, nothing changed inside
        {
            if(map == 0)
            {
                for (int i = 0; i < 20; i++)
                {
                    for (int j = 0; j < 20; j++)
                    {
                        foreach (int id in board_list[CurrentMap].boardpos[i, j].pos)
                        {

                            //   string path = "pack:/,,,/Image/" + id.ToString() + ".bmp";
                            Image temp = new Image();
                            temp.Source = BitmapImageList[id];// BitmapFromUri(path);

                            Imagelist.Add(temp);
                            int num = Imagelist.Count;

                            Imagelist[num - 1].Height = ImageSize;
                            Imagelist[num - 1].Width = ImageSize;

                            Canvas.SetLeft(Imagelist[num - 1], j * ImageSize + ImageSize);
                            Canvas.SetTop(Imagelist[num - 1], i * ImageSize + ImageSize);
                            canvas.Children.Add(Imagelist[num - 1]);
                            temp = null;

                        }

                    }
                }
            }
            else if (map == 1) // draw textmap
            {
                string s = "";
                for (int i = 0; i < 20; i++)
                {
                    for (int j = 0; j < 20; j++)
                    {
                        int num = board_list[CurrentMap].boardpos[i, j].pos.Count;
                        int id = board_list[CurrentMap].boardpos[i, j].pos[num - 1];
                        s = s + id_num[id];

                    }
                    s = s + System.Environment.NewLine;
                }
                textboard.Text = s;

            }
            
           
        }
        


        public void deletepic()
        {
            foreach (Image temp in Imagelist)
                temp.Source = null;
            return;
        }
        public void StoreBitmap()
        {
            BitmapImageList.Add(bmp0);
            BitmapImageList.Add(bmp1);
            BitmapImageList.Add(bmp2);
            BitmapImageList.Add(bmp3);
            BitmapImageList.Add(bmp4);
            BitmapImageList.Add(bmp5);
            BitmapImageList.Add(bmp6);
            BitmapImageList.Add(bmp7);
            BitmapImageList.Add(bmp8);
            BitmapImageList.Add(bmp9);
            BitmapImageList.Add(bmp10);
            BitmapImageList.Add(bmp11);
            BitmapImageList.Add(bmp12);
            BitmapImageList.Add(bmp13);
            BitmapImageList.Add(bmp14);
            BitmapImageList.Add(bmp15);
            BitmapImageList.Add(bmp16);
            BitmapImageList.Add(bmp17);
            BitmapImageList.Add(bmp18);
            BitmapImageList.Add(bmp19);
            BitmapImageList.Add(bmp20);
            BitmapImageList.Add(bmp21);
            BitmapImageList.Add(bmp22);
            BitmapImageList.Add(bmp23);
            BitmapImageList.Add(bmp24);
            BitmapImageList.Add(bmp25);
            BitmapImageList.Add(bmp26);
            BitmapImageList.Add(bmp27);
            BitmapImageList.Add(bmp28);
            BitmapImageList.Add(bmp29);
            BitmapImageList.Add(bmp30);
            BitmapImageList.Add(bmp31);
            BitmapImageList.Add(bmp32);
            BitmapImageList.Add(bmp33);
            BitmapImageList.Add(bmp34);
            BitmapImageList.Add(bmp35);
            BitmapImageList.Add(bmp36);
            BitmapImageList.Add(bmp37);
            BitmapImageList.Add(bmp38);
            BitmapImageList.Add(bmp39);
            BitmapImageList.Add(bmp40);
            BitmapImageList.Add(bmp41);
            BitmapImageList.Add(bmp42);

        }



        private void Key_control_player(object sender, KeyEventArgs e)
        {
            if (e.Key == Key.Down)
                DOWN_Click(sender, e);
            else if (e.Key == Key.Up)
                Up_Click(sender, e);
            else if (e.Key == Key.Left)
                Left_Click(sender, e);
            else if (e.Key == Key.Right)
                Right_Click(sender, e);
            else if (e.Key == Key.Z)
                Z_Click(sender, e);
        }

        //下方检查的：1，2，3， x+1
        private int Check_down(int x, int y, gameboard tempboard, int state) // state = 1 可以推， 否则不能
        {
            int num = tempboard.boardpos[x, y].pos.Count;
            for (int i = 0; i < num; i++)
            {
                int id = tempboard.boardpos[x, y].pos[i];
                if (Check_Stoppable(id) == true || x > 19)                  // 这是是类型 1,存在STOP， 不能推
                {
                    //    MessageBox.Show("Triggered! 1"+" " +y+" "+id);
                    return 1; //1

                }
            }

            // 如果到这一步说明不存在STOP且未出界
            for (int i = 0; i < num; i++)
            {
                int id = tempboard.boardpos[x, y].pos[i];
                if (Check_Pushable(id) == true) // 说明是存在可以推的，取决于下一个
                    return Check_down(x + 1, y, tempboard, 1);
            }

            //到这里说明都不是STOP且未出界且都不是PUSH
            if (state == 0) //说明不是PUSH
            {
                //   MessageBox.Show("Triggered! 3");
                return 3; //3
            }
            else if (state == 1) //说明是PUSH
            {
                //   MessageBox.Show("Triggered! 2");
                return 2;
            }
            else return 0;
        }

        //画下面的
        private void draw_push_down(int x, int y, gameboard tempboard)//能CALL这个函数说明都无STOP，这个方向可以推
        {
            int num1 = tempboard.boardpos[x, y].pos.Count;
            for (int i = 0; i < num1; i++)
            {
                int id = tempboard.boardpos[x, y].pos[i];
                //   MessageBox.Show("ID is" + id);
                if (Check_Pushable(id) == true)
                {
                    draw_push_down(x + 1, y, tempboard);
                    //      MessageBox.Show("Triggered!");
                }
            }

            //到这里表示下边没有PUSH == TRUE 的了，所以直接把所有（x - 1 ,y）位置的PUSHABLE或PLAYERID的块移到(x,y)即可
            int num = tempboard.boardpos[x - 1, y].pos.Count;
            for (int i = 0; i < num; i++)
            {
                int id = tempboard.boardpos[x - 1, y].pos[i];
                //   MessageBox.Show("The id is" + id);
                if (Check_Pushable(id) == true || id == player_id[CurrentMap])
                {

                    tempboard.boardpos[x, y].pos.Add(id);
                    tempboard.boardpos[x - 1, y].pos.Remove(id);
                }
            }
            return;
        }

        //上方检查的：1，2，3, x-1
        private int Check_up(int x, int y, gameboard tempboard, int state) // state = 1 可以推， 否则不能
        {
            int num = tempboard.boardpos[x, y].pos.Count;
            for (int i = 0; i < num; i++)
            {
                int id = tempboard.boardpos[x, y].pos[i];
                if (Check_Stoppable(id) == true || x < 0)// 这是是类型 1,存在STOP， 不能推
                {
                    //MessageBox.Show("Triggered! 1"+" " +y+" "+id);
                    return 1; //1

                }
            }

            // 如果到这一步说明不存在STOP且未出界
            for (int i = 0; i < num; i++)
            {
                int id = tempboard.boardpos[x, y].pos[i];
                if (Check_Pushable(id) == true) // 说明是存在可以推的，取决于下一个
                    return Check_up(x - 1, y, tempboard, 1);
            }

            //到这里说明都不是STOP且未出界且都不是PUSH
            if (state == 0) //说明不是PUSH
            {
                //   MessageBox.Show("Triggered! 3");
                return 3; //3

            }
            else if (state == 1) //说明是PUSH
            {
                //   MessageBox.Show("Triggered! 2");
                return 2;

            }
            else return 0;
        }

        //画上面的
        private void draw_push_up(int x, int y, gameboard tempboard)//能CALL这个函数说明都无STOP，这个方向可以推
        {
            int num1 = tempboard.boardpos[x, y].pos.Count;
            for (int i = 0; i < num1; i++)
            {
                int id = tempboard.boardpos[x, y].pos[i];
                //   MessageBox.Show("ID is" + id);
                if (Check_Pushable(id) == true)
                {
                    draw_push_up(x - 1, y, tempboard);
                    //      MessageBox.Show("Triggered!");
                }
            }

            //到这里表示上边没有PUSH == TRUE 的了，所以直接把所有（x + 1,y）位置的PUSHABLE或PLAYERID的块移到(x,y)即可
            int num = tempboard.boardpos[x + 1, y].pos.Count;
            for (int i = 0; i < num; i++)
            {
                int id = tempboard.boardpos[x + 1, y].pos[i];
                //   MessageBox.Show("The id is" + id);
                if (Check_Pushable(id) == true || id == player_id[CurrentMap])
                {

                    tempboard.boardpos[x, y].pos.Add(id);
                    tempboard.boardpos[x + 1, y].pos.Remove(id);
                }
            }
            return;
        }

        //左边检查的：1，2，3
        private int Check_left(int x, int y, gameboard tempboard, int state) // state = 1 可以推， 否则不能
        {
            int num = tempboard.boardpos[x, y].pos.Count;
            for (int i = 0; i < num; i++)
            {
                int id = tempboard.boardpos[x, y].pos[i];
                if (Check_Stoppable(id) == true || y < 0)// 这是是类型 1,存在STOP， 不能推
                {
                    //         MessageBox.Show("Triggered! 1"+" " +y+" "+id);
                    return 1; //1

                }
            }

            // 如果到这一步说明不存在STOP且未出界
            for (int i = 0; i < num; i++)
            {
                int id = tempboard.boardpos[x, y].pos[i];
                if (Check_Pushable(id) == true) // 说明是存在可以推的，取决于下一个
                    return Check_left(x, y - 1, tempboard, 1);
            }

            //到这里说明都不是STOP且未出界且都不是PUSH
            if (state == 0) //说明不是PUSH
            {
                //       MessageBox.Show("Triggered! 3");
                return 3; //3

            }
            else if (state == 1) //说明是PUSH
            {
                //      MessageBox.Show("Triggered! 2");
                return 2;

            }
            else return 0;
        }
        //画左边的：
        private void draw_push_left(int x, int y, gameboard tempboard)//能CALL这个函数说明都无STOP，这个方向可以推
        {
            int num1 = tempboard.boardpos[x, y].pos.Count;
            for (int i = 0; i < num1; i++)
            {
                int id = tempboard.boardpos[x, y].pos[i];
                //   MessageBox.Show("ID is" + id);
                if (Check_Pushable(id) == true)
                {
                    draw_push_left(x, y - 1, tempboard);
                    //      MessageBox.Show("Triggered!");
                }
            }

            //到这里表示左边没有PUSH == TRUE 的了，所以直接把所有（x,y+1）位置的PUSHABLE或PLAYERID的块移到(x,y)即可
            int num = tempboard.boardpos[x, y + 1].pos.Count;
            for (int i = 0; i < num; i++)
            {
                int id = tempboard.boardpos[x, y + 1].pos[i];
                //   MessageBox.Show("The id is" + id);
                if (Check_Pushable(id) == true || id == player_id[CurrentMap])
                {

                    tempboard.boardpos[x, y].pos.Add(id);
                    tempboard.boardpos[x, y + 1].pos.Remove(id);
                }
            }
            return;
        }

        //检查右边相邻的块为1或2或3
        private int Check_right(int x, int y, gameboard tempboard, int state) // state = 1 可以推， 否则不能
        {
            int num = tempboard.boardpos[x, y].pos.Count;
            for (int i = 0; i < num; i++)
            {
                int id = tempboard.boardpos[x, y].pos[i];
                if (Check_Stoppable(id) == true || y > 19)// 这是是类型 1,存在STOP， 不能推
                {
                    //    MessageBox.Show("Triggered! 1"+" " +y+" "+id);
                    return 1; //1

                }
            }

            // 如果到这一步说明不存在STOP且未出界
            for (int i = 0; i < num; i++)
            {
                int id = tempboard.boardpos[x, y].pos[i];
                if (Check_Pushable(id) == true) // 说明是存在可以推的，取决于下一个
                    return Check_right(x, y + 1, tempboard, 1);
            }

            //到这里说明都不是STOP且未出界且都不是PUSH
            if (state == 0) //说明不是PUSH
            {
                //   MessageBox.Show("Triggered! 3");
                return 3; //3
            }
            else if (state == 1) //说明是PUSH
            {
                //   MessageBox.Show("Triggered! 2");
                return 2;

            }
            else return 0;
        }

        //这个函数和draw_push_direction类似
        private void draw_push_right(int x, int y, gameboard tempboard)//能CALL这个函数说明都无STOP，这个方向可以推
        {
            int num1 = tempboard.boardpos[x, y].pos.Count;
            for (int i = 0; i < num1; i++)
            {
                int id = tempboard.boardpos[x, y].pos[i];
                //   MessageBox.Show("ID is" + id);
                if (Check_Pushable(id) == true)
                {
                    draw_push_right(x, y + 1, tempboard);
                    //      MessageBox.Show("Triggered!");
                }
            }

            //到这里表示右边没有PUSH == TRUE 的了，所以直接把所有（x,y-1）位置的PUSHABLE或PLAYERID的块移到(x,y)即可
            int num = tempboard.boardpos[x, y - 1].pos.Count;
            for (int i = 0; i < num; i++)
            {
                int id = tempboard.boardpos[x, y - 1].pos[i];
                //   MessageBox.Show("The id is" + id);
                if (Check_Pushable(id) == true || id == player_id[CurrentMap])
                {

                    tempboard.boardpos[x, y].pos.Add(id);
                    tempboard.boardpos[x, y - 1].pos.Remove(id);
                }
            }
            return;
        }


        public bool get_isslip(int id)
        {
            foreach (var element in GameObjectList)
                if (element.id == id)
                    return element.isslip;
            return false;
        }

        public bool get_isslip_pos(gameboard tempboard, int x, int y)
        {
            foreach (int id in tempboard.boardpos[x, y].pos)
            {
                if (get_isslip(id))
                    return true;  //如果位置上存在SLIP元素则为TRUE
            }
            return false;
        }

        public void change_slip_dir(int id, int direction)
        {
            foreach (var element in GameObjectList)
            {
                if (element.id == id)
                {
                    element.slip_direction = direction;
                    return;
                }
            }
        }

        public int get_slip(int id)
        {
            foreach (var element in GameObjectList)
                if (element.id == id)
                    return element.slip_direction;
            return 0;
        }

        public static void Sink_Map(gameboard tempboard)
        {
            for (int i = 0; i < 20; i++)
            {
                for (int j = 0; j < 20; j++)
                {
                    if (tempboard.boardpos[i, j].pos.Count() > 2)   //check that if more than 2 element then sink event can happen
                    {
                        foreach (var element_a in GameObjectList)
                        {

                            if (tempboard.boardpos[i, j].pos.Contains(element_a.id) && element_a.issink == true) //c
                            {
                                tempboard.boardpos[i, j].pos.Clear();
                                tempboard.boardpos[i, j].pos.Add(0);
                            }
                        }
                    }
                }
            }
        }

        public static void Melt_map(gameboard tempboard)
        {
            for (int i = 0; i < 20; i++)
            {
                for (int j = 0; j < 20; j++)
                {
                    if (tempboard.boardpos[i, j].pos.Count() > 2)   //check that if more than 2 element then sink event can happen
                    {
                        foreach (var element_a in GameObjectList)
                        {
                            foreach(var element_b in GameObjectList)
                            {
                                if (element_a.ishot == true && element_b.ismelt== true && tempboard.boardpos[i, j].pos.Contains(element_a.id) && tempboard.boardpos[i, j].pos.Contains(element_b.id))
                                {
                                    tempboard.boardpos[i, j].pos.Remove(element_b.id);

                                    if(element_b.id ==4)    //case of player is melt
                                    {
                                        MessageBox.Show("Baba is melt. Please press Z key and try again");
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }

        public void Exchange_id(gameboard tempboard)
        {
            for (int i = 0; i < 20; i++)
            {
                for (int j = 0; j < 20; j++)
                {
                    foreach (var element in first_id)
                    {
                        if (tempboard.boardpos[i, j].pos.Contains(element))
                        {
                            //tempboard.boardpos[i, j].pos.Clear();
                            tempboard.boardpos[i, j].pos.Remove(element);
                            tempboard.boardpos[i, j].pos.Add(second_id[0]);
                        }
                    }
                }
            }
        }

        //右击发生事件： 1.不能动，右边为STOP，2. 可以推， 右边并未到底且无STOP， 3. 简单移动
        public void Right_Click(object sender, RoutedEventArgs e)
        {
            deletepic();
            if (Initailized)
            {
                gameboard tempboard = new gameboard();
                cp_temp(tempboard); //这一步把当前的棋盘复制到TEMPBOARD了
                int next_id = player_id[CurrentMap]; // 这个变量决定这一步之后的PLAYER ID是多少，应该在对应的FUNCTION里面改（YOU）
                for (int i = 0; i < 20; i++)
                {
                    for (int j = 0; j < 20; j++)
                    {
                        foreach (int id in board_list[CurrentMap].boardpos[i, j].pos)
                        {
                            if (id == player_id[CurrentMap])//若为当前ID，则进行操作， 右边为X不变，Y加一
                            {
                                int slip_type = get_slip(id);
                                if (slip_type == 0 || slip_type == 4 || slip_type == 3)
                                {
                                    bool isslip = get_isslip_pos(tempboard, i, j + 1);
                                    int move_type = Check_right(i, j + 1, tempboard, 0);
                                    switch (move_type)
                                    {
                                        case 1:
                                            // do nothing now, since no move
                                            break;
                                        case 2:
                                            draw_push_right(i, j + 1, tempboard);
                                            break;
                                        case 3:// this is simply move ,不过可能还有触发逻辑
                                            tempboard.boardpos[i, j].pos.Remove(id);
                                            tempboard.boardpos[i, j + 1].pos.Add(id);
                                            break;
                                    }
                                    if (isslip == true)
                                        change_slip_dir(id, 4);
                                    else
                                        change_slip_dir(id, 0);
                                }


                                TouchToPassOrDie(tempboard, i, j + 1);

                            }
                        }
                    }
                }
                //也许在这里（所有都走完后再触发逻辑？）或者每一步都触发一次？（只要不是不动）
                // after all the change, we update the gameboard and current board;
                //need to use tempboard 
                //player id changing use cp_temp(tempboard);
                horizontal_logic(tempboard);
                vertical_logic(tempboard);
                WinOrLoseOrGoOn(win_state, lose_state);
                Sink_Map(tempboard);
                Melt_map(tempboard);
                Move_object_move(tempboard);
                Exchange_id(tempboard);
                //TestMessage(29); //This is used to check stoppable, pushable, Ispass, IsDie Bool value

                board_list.Add(tempboard);
                player_id.Add(next_id);
                CurrentMap++;
                DrawMap();
                first_id.Clear();
                second_id.Clear();
                tempboard = null;
            }
        }







        // the main changes below are due to the change above actually, 
        //we need to think about the case of 推箱子 
        //since if you move in one direction, more than one 
        // block will be changed!. Think about this if you can!!!!!!!!!!!!
        public void Up_Click(object sender, RoutedEventArgs e)
        {
            deletepic();

            if (Initailized)
            {
                gameboard tempboard = new gameboard();
                cp_temp(tempboard); //这一步把当前的棋盘复制到TEMPBOARD了
                int next_id = player_id[CurrentMap]; // 这个变量决定这一步之后的PLAYER ID是多少，应该在对应的FUNCTION里面改（YOU）
                for (int i = 0; i < 20; i++)
                {
                    for (int j = 0; j < 20; j++)
                    {
                        foreach (int id in board_list[CurrentMap].boardpos[i, j].pos)
                        {
                            if (id == player_id[CurrentMap])//若为当前ID，则进行操作， 右边为X不变，Y加一
                            {
                                int slip_type = get_slip(id);

                                if (slip_type == 0 || slip_type == 1 || slip_type == 2)
                                {
                                    bool isslip = get_isslip_pos(tempboard, i - 1, j);
                                    int move_type = Check_up(i - 1, j, tempboard, 0);
                                    switch (move_type)
                                    {
                                        case 1:
                                            // do nothing now, since no move
                                            break;
                                        case 2:
                                            draw_push_up(i - 1, j, tempboard);
                                            break;
                                        case 3:// this is simply move ,不过可能还有触发逻辑
                                            tempboard.boardpos[i, j].pos.Remove(id);
                                            tempboard.boardpos[i - 1, j].pos.Add(id);
                                            break;
                                    }
                                    if (isslip == true)
                                        change_slip_dir(id, 1);
                                    else
                                        change_slip_dir(id, 0);
                                }

                                TouchToPassOrDie(tempboard, i - 1, j);

                            }
                        }
                    }
                }

                //也许在这里（所有都走完后再触发逻辑？）或者每一步都触发一次？（只要不是不动）
                // after all the change, we update the gameboard and current board;
                horizontal_logic(tempboard);
                vertical_logic(tempboard);
                WinOrLoseOrGoOn(win_state, lose_state);
                Sink_Map(tempboard);
                Melt_map(tempboard);
                Move_object_move(tempboard);
                Exchange_id(tempboard);

                //TestMessage(29); //This is used to check stoppable, pushable, Ispass, IsDie Bool value

                board_list.Add(tempboard);
                player_id.Add(next_id);
                CurrentMap++;
                DrawMap();
                first_id.Clear();
                second_id.Clear();
                tempboard = null;
            }
        }


        public void Left_Click(object sender, RoutedEventArgs e)
        {
            deletepic();

            if (Initailized)
            {
                gameboard tempboard = new gameboard();
                cp_temp(tempboard); //这一步把当前的棋盘复制到TEMPBOARD了
                int next_id = player_id[CurrentMap]; // 这个变量决定这一步之后的PLAYER ID是多少，应该在对应的FUNCTION里面改（YOU）
                for (int i = 0; i < 20; i++)
                {
                    for (int j = 0; j < 20; j++)
                    {
                        foreach (int id in board_list[CurrentMap].boardpos[i, j].pos)
                        {
                            if (id == player_id[CurrentMap])//若为当前ID，则进行操作， 右边为X不变，Y加一
                            {
                                int slip_type = get_slip(id);
                                if (slip_type == 0 || slip_type == 3 || slip_type == 4)
                                {
                                    bool isslip = get_isslip_pos(tempboard, i, j - 1);
                                    int move_type = Check_left(i, j - 1, tempboard, 0);
                                    switch (move_type)
                                    {
                                        case 1:
                                            // do nothing now, since no move
                                            break;
                                        case 2:
                                            draw_push_left(i, j - 1, tempboard);
                                            break;
                                        case 3:// this is simply move ,不过可能还有触发逻辑
                                            tempboard.boardpos[i, j].pos.Remove(id);
                                            tempboard.boardpos[i, j - 1].pos.Add(id);
                                            break;
                                    }
                                    if (isslip == true)
                                        change_slip_dir(id, 3);
                                    else
                                        change_slip_dir(id, 0);
                                }


                                TouchToPassOrDie(tempboard, i, j - 1);

                            }
                        }
                    }
                }
                //也许在这里（所有都走完后再触发逻辑？）或者每一步都触发一次？（只要不是不动）
                // after all the change, we update the gameboard and current board;
                horizontal_logic(tempboard);
                vertical_logic(tempboard);
                WinOrLoseOrGoOn(win_state, lose_state);
                Sink_Map(tempboard);
                Melt_map(tempboard);
                Move_object_move(tempboard);
                Exchange_id(tempboard);

                //TestMessage(29); //This is used to check stoppable, pushable, Ispass, IsDie Bool value

                board_list.Add(tempboard);
                player_id.Add(next_id);
                CurrentMap++;
                DrawMap();
                first_id.Clear();
                second_id.Clear();
                tempboard = null;
            }
        }

        public void DOWN_Click(object sender, RoutedEventArgs e)
        {
            deletepic();

            if (Initailized)
            {
                gameboard tempboard = new gameboard();
                cp_temp(tempboard); //这一步把当前的棋盘复制到TEMPBOARD了
                int next_id = player_id[CurrentMap]; // 这个变量决定这一步之后的PLAYER ID是多少，应该在对应的FUNCTION里面改（YOU）
                for (int i = 0; i < 20; i++)
                {
                    for (int j = 0; j < 20; j++)
                    {
                        foreach (int id in board_list[CurrentMap].boardpos[i, j].pos)
                        {
                            if (id == player_id[CurrentMap])//若为当前ID，则进行操作， 右边为X不变，Y加一
                            {
                                int slip_type = get_slip(id);
                                if (slip_type == 0 || slip_type == 2 || slip_type == 1)
                                {
                                    bool isslip = get_isslip_pos(tempboard, i + 1, j);
                                    int move_type = Check_down(i + 1, j, tempboard, 0);
                                    switch (move_type)
                                    {
                                        case 1:
                                            // do nothing now, since no move
                                            break;
                                        case 2:
                                            draw_push_down(i + 1, j, tempboard);
                                            break;
                                        case 3:// this is simply move ,不过可能还有触发逻辑
                                            tempboard.boardpos[i, j].pos.Remove(id);
                                            tempboard.boardpos[i + 1, j].pos.Add(id);
                                            break;
                                    }
                                    if (isslip == true)
                                        change_slip_dir(id, 2);
                                    else
                                        change_slip_dir(id, 0);
                                }

                                TouchToPassOrDie(tempboard, i + 1, j);

                            }
                        }
                    }
                }
                //也许在这里（所有都走完后再触发逻辑？）或者每一步都触发一次？（只要不是不动）
                // after all the change, we update the gameboard and current board;

                horizontal_logic(tempboard);
                vertical_logic(tempboard);
                WinOrLoseOrGoOn(win_state, lose_state);
                Sink_Map(tempboard);
                Melt_map(tempboard);
                Move_object_move(tempboard);

                Exchange_id(tempboard);

                //TestMessage(29); //This is used to check stoppable, pushable, Ispass, IsDie Bool value


                board_list.Add(tempboard);
                player_id.Add(next_id);
                CurrentMap++;
                DrawMap();
                first_id.Clear();
                second_id.Clear();
                tempboard = null;
            }
        }

        public void Z_slip()
        {
            for (int i = 0; i < 20; i++)
            {
                for (int j = 0; j < 20; j++)
                {
                    foreach (int id in board_list[CurrentMap].boardpos[i, j].pos)
                    {
                        if (id == player_id[CurrentMap])
                        {
                            bool isslip = get_isslip_pos(board_list[CurrentMap], i, j);
                            if (isslip == false)
                                change_slip_dir(id, 0);
                        }


                    }
                }
            }
        }
        private void Z_Click(object sender, RoutedEventArgs e)
        {
            win_state = false;
            lose_state = false;
            deletepic();
            if (Initailized)
            {
                if (CurrentMap > 0)
                {
                    board_list.RemoveAt(CurrentMap); // delete the current map
                    player_id.RemoveAt(CurrentMap);
                    CurrentMap--;
                    // update_Cnum();
                    Z_slip();
                    DrawMap();
                }
            }
            gameboard tempboard = new gameboard();
            cp_temp(tempboard); //这一步把当前的棋盘复制到TEMPBOARD了
            horizontal_logic(tempboard);
            vertical_logic(tempboard);
            //123 121 logic need add here 
        }

        private void HandleEsc(object sender, KeyEventArgs e)// for close window (press esc)
        {
            if (e.Key == Key.Escape) Close();
        }


        public MainWindow()
        {
            InitializeComponent();
            Game_entry1.Visibility = Visibility.Hidden;
            Game_entry2.Visibility = Visibility.Hidden;
            Game_entry3.Visibility = Visibility.Hidden;
            move_x.Add(4);
            move_y.Add(15);
            this.PreviewKeyDown += new KeyEventHandler(HandleEsc);
            this.PreviewKeyDown += new KeyEventHandler(Key_control_player);
        }

        private void Normalmap_Click(object sender, RoutedEventArgs e)
        {
            map = 0;
            Normalmap.Visibility = Visibility.Hidden;
            Textmap.Visibility = Visibility.Hidden;
            Game_entry1.Visibility = Visibility.Visible;
            Game_entry2.Visibility = Visibility.Visible;
            Game_entry3.Visibility = Visibility.Visible;
            return;
        }

        private void Textmap_Click(object sender, RoutedEventArgs e)
        {
            map = 1;
            Normalmap.Visibility = Visibility.Hidden;
            Textmap.Visibility = Visibility.Hidden;
            Game_entry1.Visibility = Visibility.Visible;
            Game_entry2.Visibility = Visibility.Visible;
            Game_entry3.Visibility = Visibility.Visible;
            return;
        }
        public void Game_entry1_Click(object sender, RoutedEventArgs e)
        {
            //if click this button then all button become invisible
            Game_entry1.Visibility = Visibility.Hidden;
            Game_entry2.Visibility = Visibility.Hidden;
            Game_entry3.Visibility = Visibility.Hidden;

            BitmapImageList = new List<BitmapImage>();


            add_id_num();

            StoreBitmap();

            CurrentMap = 0;

            ImageSize = 40;

            player_id.Add(4); // first player is 4: baba_object
            InitailizeMap_1(); //draw the first map

            Initailized = true;
            return;

        }
        public void Game_entry2_Click(object sender, RoutedEventArgs e)
        {
            //if click this button then all button become invisible
            Game_entry1.Visibility = Visibility.Hidden;
            Game_entry2.Visibility = Visibility.Hidden;
            Game_entry3.Visibility = Visibility.Hidden;
            BitmapImageList = new List<BitmapImage>();


            add_id_num();

            StoreBitmap();

            CurrentMap = 0;

            ImageSize = 40;

            player_id.Add(4); // first player is 4: baba_object

            InitailizeMap_2(); //draw the first map

            Initailized = true;
            return;

        }
        public void Game_entry3_Click(object sender, RoutedEventArgs e)
        {
            //if click this button then all button become invisible
            Game_entry1.Visibility = Visibility.Hidden;
            Game_entry2.Visibility = Visibility.Hidden;
            Game_entry3.Visibility = Visibility.Hidden;
            BitmapImageList = new List<BitmapImage>();


            add_id_num();

            StoreBitmap();

            CurrentMap = 0;

            ImageSize = 40;

            player_id.Add(4); // first player is 4: baba_object

            InitailizeMap_3(); //draw the first map

            Initailized = true;
            return;
        }
        public void InitailizeMap_1()
        {
            gameboard tempgameboard = new gameboard(); // tempboard
            initial_temp(tempgameboard);
            for (int i = 0; i < 20; i++) //draw grass obj=15
            {
                tempgameboard.boardpos[19, i].pos.Add(15);
                tempgameboard.boardpos[0, i].pos.Add(15);
            }
            for (int i = 1; i < 19; i++) //draw grass obj=15
            {
                tempgameboard.boardpos[i, 0].pos.Add(15);
                tempgameboard.boardpos[i, 19].pos.Add(15);
            }

            //draw wall is stop 
            tempgameboard.boardpos[5, 5].pos.Add(33);
            tempgameboard.boardpos[5, 6].pos.Add(2);
            tempgameboard.boardpos[5, 7].pos.Add(32);

            //draw rock is push 
            tempgameboard.boardpos[5, 10].pos.Add(28);
            tempgameboard.boardpos[5, 11].pos.Add(2);
            tempgameboard.boardpos[5, 12].pos.Add(27);

            //draw row 7 wall
            for (int col = 4; col < 18; col++)
            {
                tempgameboard.boardpos[7, col].pos.Add(5);
            }
            //draw palyer 
            tempgameboard.boardpos[9, 7].pos.Add(4);

            //draw rock in the middle 
            tempgameboard.boardpos[8, 10].pos.Add(29);
            tempgameboard.boardpos[9, 10].pos.Add(29);
            tempgameboard.boardpos[10, 10].pos.Add(29);

            //draw flag obj
            tempgameboard.boardpos[9, 14].pos.Add(14);

            //draw row 11 wall
            for (int col = 4; col < 18; col++)
            {
                tempgameboard.boardpos[11, col].pos.Add(5);
            }

            //draw baba is you 
            tempgameboard.boardpos[13, 5].pos.Add(1);
            tempgameboard.boardpos[13, 6].pos.Add(2);
            tempgameboard.boardpos[13, 7].pos.Add(3);

            ///draw flag is win 
            tempgameboard.boardpos[13, 10].pos.Add(13);
            tempgameboard.boardpos[13, 11].pos.Add(2);
            tempgameboard.boardpos[13, 12].pos.Add(35);
            board_list.Add(tempgameboard);
            DrawMap();
        }

        public void InitailizeMap_2()
        {

            gameboard tempgameboard = new gameboard(); // tempboard
            initial_temp(tempgameboard);


            for (int i = 0; i < 20; i++) //draw grass obj=15
            {
                tempgameboard.boardpos[19, i].pos.Add(15);
                tempgameboard.boardpos[0, i].pos.Add(15);
            }
            for (int i = 1; i < 19; i++) //draw grass obj=15
            {
                tempgameboard.boardpos[i, 0].pos.Add(15);
                tempgameboard.boardpos[i, 19].pos.Add(15);
            }

            //draw row 4
            tempgameboard.boardpos[4, 8].pos.Add(7);
            tempgameboard.boardpos[4, 9].pos.Add(5);
            tempgameboard.boardpos[4, 10].pos.Add(5);
            tempgameboard.boardpos[4, 11].pos.Add(5);
            tempgameboard.boardpos[4, 12].pos.Add(5);
            tempgameboard.boardpos[4, 13].pos.Add(5);
            tempgameboard.boardpos[4, 14].pos.Add(5);
            tempgameboard.boardpos[4, 15].pos.Add(9);

            //drawe row 5
            tempgameboard.boardpos[5, 8].pos.Add(37);
            tempgameboard.boardpos[5, 15].pos.Add(37);

            //drawe row 6 is in here
            tempgameboard.boardpos[6, 8].pos.Add(37);
            tempgameboard.boardpos[6, 15].pos.Add(37);
            tempgameboard.boardpos[6, 10].pos.Add(2);

            //draw row 7 
            tempgameboard.boardpos[7, 4].pos.Add(7);
            tempgameboard.boardpos[7, 5].pos.Add(5);
            tempgameboard.boardpos[7, 6].pos.Add(5);
            tempgameboard.boardpos[7, 7].pos.Add(5);
            tempgameboard.boardpos[7, 8].pos.Add(8);
            tempgameboard.boardpos[7, 13].pos.Add(35);
            tempgameboard.boardpos[7, 15].pos.Add(37);

            //draw col 4
            tempgameboard.boardpos[7, 4].pos.Add(7);
            tempgameboard.boardpos[8, 4].pos.Add(37);
            tempgameboard.boardpos[9, 4].pos.Add(37);
            tempgameboard.boardpos[10, 4].pos.Add(37);
            tempgameboard.boardpos[11, 4].pos.Add(6);

            //draw row 11
            tempgameboard.boardpos[11, 5].pos.Add(6);
            tempgameboard.boardpos[11, 6].pos.Add(5);
            tempgameboard.boardpos[11, 7].pos.Add(5);
            tempgameboard.boardpos[11, 8].pos.Add(5);
            tempgameboard.boardpos[11, 9].pos.Add(5);
            tempgameboard.boardpos[11, 10].pos.Add(5);
            tempgameboard.boardpos[11, 11].pos.Add(5);
            tempgameboard.boardpos[11, 12].pos.Add(5);
            tempgameboard.boardpos[11, 13].pos.Add(5);
            tempgameboard.boardpos[11, 14].pos.Add(5);
            tempgameboard.boardpos[11, 15].pos.Add(5);

            //draw wall
            tempgameboard.boardpos[8, 15].pos.Add(37);
            tempgameboard.boardpos[9, 15].pos.Add(37);
            tempgameboard.boardpos[10, 15].pos.Add(37);

            //draw flag and flag obj
            tempgameboard.boardpos[9, 6].pos.Add(13);
            tempgameboard.boardpos[9, 9].pos.Add(14);

            //draw palyer
            tempgameboard.boardpos[8, 12].pos.Add(4);

            //draw baba is you  in col4
            tempgameboard.boardpos[13, 4].pos.Add(1);
            tempgameboard.boardpos[14, 4].pos.Add(2);
            tempgameboard.boardpos[15, 4].pos.Add(3);

            //draw wall is stop  in col7
            tempgameboard.boardpos[13, 7].pos.Add(33);
            tempgameboard.boardpos[14, 7].pos.Add(2);
            tempgameboard.boardpos[15, 7].pos.Add(32);

            board_list.Add(tempgameboard);
            DrawMap();
        }
        public void InitailizeMap_3()
        {

            gameboard tempgameboard = new gameboard(); // tempboard
            initial_temp(tempgameboard);

            for (int i = 0; i < 20; i++) //draw grass obj=15
            {
                tempgameboard.boardpos[19, i].pos.Add(15);
                tempgameboard.boardpos[0, i].pos.Add(15);
            }
            for (int i = 1; i < 19; i++) //draw grass obj=15
            {
                tempgameboard.boardpos[i, 0].pos.Add(15);
                tempgameboard.boardpos[i, 19].pos.Add(15);
            }

            //draw keke is move
            tempgameboard.boardpos[1, 1].pos.Add(19);
            tempgameboard.boardpos[1, 2].pos.Add(2);
            tempgameboard.boardpos[1, 3].pos.Add(25);

            //draw rock is push and goop is sink
            tempgameboard.boardpos[13, 1].pos.Add(28); //rock 
            tempgameboard.boardpos[14, 1].pos.Add(2);
            tempgameboard.boardpos[15, 1].pos.Add(27);   //push
            tempgameboard.boardpos[16, 1].pos.Add(40); //goop water_word
            tempgameboard.boardpos[17, 1].pos.Add(2);
            tempgameboard.boardpos[18, 1].pos.Add(41);  //sink

            //draw keke_obj
            tempgameboard.boardpos[4, 15].pos.Add(22);  //keke obj

            //draw wall that circle keke_obj
            tempgameboard.boardpos[1, 13].pos.Add(5);
            tempgameboard.boardpos[2, 13].pos.Add(5);
            tempgameboard.boardpos[3, 13].pos.Add(5);
            tempgameboard.boardpos[4, 13].pos.Add(5);
            tempgameboard.boardpos[5, 13].pos.Add(5);
            tempgameboard.boardpos[6, 13].pos.Add(5);
            tempgameboard.boardpos[7, 13].pos.Add(5);
            tempgameboard.boardpos[7, 14].pos.Add(5);
            tempgameboard.boardpos[7, 15].pos.Add(5);
            tempgameboard.boardpos[7, 16].pos.Add(5);
            tempgameboard.boardpos[7, 17].pos.Add(5);
            tempgameboard.boardpos[7, 18].pos.Add(5);

            //draw water that circle empty is  win
            tempgameboard.boardpos[8, 13].pos.Add(34);
            tempgameboard.boardpos[9, 13].pos.Add(34);
            tempgameboard.boardpos[10, 13].pos.Add(34);
            tempgameboard.boardpos[11, 13].pos.Add(34);
            tempgameboard.boardpos[12, 13].pos.Add(34);
            tempgameboard.boardpos[13, 13].pos.Add(34);
            tempgameboard.boardpos[14, 13].pos.Add(34);
            tempgameboard.boardpos[15, 13].pos.Add(34);
            tempgameboard.boardpos[16, 13].pos.Add(34);
            tempgameboard.boardpos[17, 13].pos.Add(34);
            tempgameboard.boardpos[18, 13].pos.Add(34);

            //draw empty is win
            tempgameboard.boardpos[8, 18].pos.Add(10);
            tempgameboard.boardpos[9, 18].pos.Add(2);
            tempgameboard.boardpos[11, 18].pos.Add(35);

            //draw lava is hot and baba is melt and lava obj
            tempgameboard.boardpos[2, 9].pos.Add(21);    //lava
            tempgameboard.boardpos[2, 10].pos.Add(2);    //is 

            tempgameboard.boardpos[1, 10].pos.Add(16);   //hot
            tempgameboard.boardpos[2, 12].pos.Add(36);   //lava obj
            tempgameboard.boardpos[3, 2].pos.Add(1);     //baba
            tempgameboard.boardpos[3, 3].pos.Add(2);     //is
            tempgameboard.boardpos[3, 4].pos.Add(24);    //melt
            tempgameboard.boardpos[3, 5].pos.Add(36);    //lava obj

            ////draw ice is slip
            tempgameboard.boardpos[8, 1].pos.Add(17);    //ice
            tempgameboard.boardpos[8, 2].pos.Add(2);    //is 
            tempgameboard.boardpos[8, 3].pos.Add(31);   //slip
            //draw ice obj
            tempgameboard.boardpos[8, 4].pos.Add(18);   //ice obj
            tempgameboard.boardpos[8, 5].pos.Add(29);   //rock obj
            tempgameboard.boardpos[8, 6].pos.Add(18);   //ice obj
            tempgameboard.boardpos[7, 4].pos.Add(18);   //ice obj
            tempgameboard.boardpos[7, 5].pos.Add(18);   //ice obj
            tempgameboard.boardpos[7, 6].pos.Add(18);   //ice obj
            tempgameboard.boardpos[9, 4].pos.Add(18);   //ice obj
            tempgameboard.boardpos[9, 5].pos.Add(18);   //ice obj
            tempgameboard.boardpos[9, 6].pos.Add(18);   //ice obj

            //draw player 
            tempgameboard.boardpos[15, 5].pos.Add(4);   //player

            //Skull is kill
            tempgameboard.boardpos[13, 11].pos.Add(30);
            tempgameboard.boardpos[14, 10].pos.Add(2);
            tempgameboard.boardpos[14, 11].pos.Add(20);
            tempgameboard.boardpos[14, 9].pos.Add(42); //skull obj 
            tempgameboard.boardpos[14, 16].pos.Add(29); //rock obj 

            //draw baba is you 
            tempgameboard.boardpos[18, 15].pos.Add(1);
            tempgameboard.boardpos[18, 16].pos.Add(2);
            tempgameboard.boardpos[18, 17].pos.Add(3);

            //draw Wall is stop
            tempgameboard.boardpos[17, 15].pos.Add(33);
            tempgameboard.boardpos[17, 16].pos.Add(2);
            tempgameboard.boardpos[17, 17].pos.Add(32);
            board_list.Add(tempgameboard);
            DrawMap();
        }


    }
}